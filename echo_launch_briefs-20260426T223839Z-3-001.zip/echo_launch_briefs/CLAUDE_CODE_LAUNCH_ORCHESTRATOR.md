# Claude Code Launch · Boot Code-as-Orchestrator

**Mission:** You become ECHO's supervisor. ECHO executes. You verify, correct, and escalate. DC sleeps. DC wakes up to a working morning Slack digest.

**Estimated runtime:** 15-25 min for first run + setup. Then runs forever via LaunchAgent.

**Source of truth:** `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/architecture/CODE_AS_ORCHESTRATOR_v1.md` — read in full before doing anything else.

---

## YOUR FIRST RUN (do this NOW, in order)

### Step 1 · Read your charter (5 min)

```
1. /Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/architecture/CODE_AS_ORCHESTRATOR_v1.md
2. /Users/echo/Documents/Claude/Projects/ECHO/ECHO-AUTONOMY-CHARTER-v4.md
3. /Users/echo/Documents/Claude/Projects/ECHO/shared-memory/shared-state.md
```

### Step 2 · Connect to Supabase + check state (3 min)

Use the Supabase MCP or direct REST against project `wovoashhorgdzydlnpzr`. Pull credentials from `/Users/echo/Documents/Claude/Projects/ECHO/ECHO-CONFIG.md`.

Run:
```sql
SELECT id, created_at, "from", "to", kind, payload, acknowledged_at
FROM echo.agent_messages
WHERE acknowledged_at IS NULL
ORDER BY created_at DESC
LIMIT 50;
```

For each unacknowledged message, decide: enforce / remediate / escalate / acknowledge per the operating loop in the charter.

### Step 3 · Run the operating loop ONCE end-to-end (10 min)

Follow Section "Code's Operating Loop" in the architecture spec. Document every step in a new section appended to shared-state.md:

```markdown
## CODE LOOP MANIFEST · 2026-04-26 [time]

### Inputs
- shared-state.md last 24h: [N entries read]
- echo.agent_messages unacknowledged: [N rows]
- ECHO heartbeat last seen: [time]

### Decisions
[For each unacknowledged message, log: action taken / remediation result / escalation status]

### Health
- n8n: [200/non-200] · last check [time]
- Supabase: [reachable/unreachable] · last check [time]
- ECHO heartbeat: [N min ago]
- Mac uptime: [X hours]

### Output
- Messages acknowledged: [N]
- Tasks re-issued: [N]
- Blockers escalated to DC: [N]
- Health alerts sent: [N]
```

### Step 4 · Install the LaunchAgent (5 min)

Build the LaunchAgent plist at:
`/Users/echo/Documents/Claude/Projects/ECHO/launchd/com.digitalmavericks.code-orchestrator.plist`

It should:
- Run every 4 hours: `StartCalendarInterval` array with hours 1, 5, 9, 13, 17, 21
- Invoke a wrapper script: `/Users/echo/Documents/Claude/Projects/ECHO/launchd/code-orchestrator-loop.sh`
- Log to `~/Library/Logs/digitalmavericks/code-orchestrator.{stdout,stderr}.log`
- Run as DC's user (LaunchAgent, not LaunchDaemon)

The wrapper script should:
- Source `~/.bashrc` or load `ECHO-CONFIG.md` env
- Invoke `claude code "$(cat /Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/echo_launch_briefs/CLAUDE_CODE_LOOP_BRIEF.md)"` (you'll write this brief in Step 5)
- Append exit code + timestamp to a loop history log

Install:
```bash
chmod +x /Users/echo/Documents/Claude/Projects/ECHO/launchd/code-orchestrator-loop.sh
cp /Users/echo/Documents/Claude/Projects/ECHO/launchd/com.digitalmavericks.code-orchestrator.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.digitalmavericks.code-orchestrator.plist
launchctl list | grep code-orchestrator
```

### Step 5 · Write the recurring loop brief (5 min)

Create `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/echo_launch_briefs/CLAUDE_CODE_LOOP_BRIEF.md` — the SHORT brief that the LaunchAgent invokes every 4 hours. It's a stripped-down version of this brief: just "run the loop once, document, exit." Don't re-read the architecture spec on every run — that's wasted tokens.

### Step 6 · Build the morning digest LaunchAgent (5 min)

Same pattern, separate plist:
`/Users/echo/Documents/Claude/Projects/ECHO/launchd/com.digitalmavericks.code-morning-digest.plist`

- `StartCalendarInterval`: Hour=9, Minute=0 (DC's local time, set Mac timezone to America/New_York or equivalent ET)
- Invokes: `/Users/echo/Documents/Claude/Projects/ECHO/launchd/code-morning-digest.sh`
- That script invokes: `claude code "$(cat /Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/echo_launch_briefs/CLAUDE_CODE_DIGEST_BRIEF.md)"`

The digest brief tells Code to: read last-24h state, summarize per the format in the architecture spec, post to DC's Slack DM.

### Step 7 · Send the FIRST digest right now (3 min)

DC is flying soon. He needs to see the wire works BEFORE he leaves. Send the first digest immediately, regardless of time:

```
🟢 ECHO ORCHESTRATOR · BOOTED · Apr 26 · [current time] ET

DONE THIS RUN:
• Code-as-Orchestrator architecture deployed
• LaunchAgents installed (4-hr loop + 9:00 ET morning digest)
• First operating loop completed · [N] messages acknowledged
• ECHO charter v4 verified active
• Health: n8n [status] · Supabase [status] · ECHO heartbeat [time ago]

NEXT 4 HOURS:
• Skill universalization Code session: [in progress / complete]
• PAO_Rebuild brief: queued, awaiting DC launch
• Board prompts brief: queued, awaiting DC launch

Wire is live. Sleep. Next digest at 9:00 AM ET tomorrow.

Code orchestrator · loop pid [N]
```

Post via Slack webhook (`SLACK_DM_DC_WEBHOOK` in ECHO-CONFIG.md, or set to DC's personal channel ID).

### Step 8 · Append a deploy note to shared-state.md

```markdown
## CODE-AS-ORCHESTRATOR DEPLOYED · 2026-04-26 [time]
- Architecture: /AIO-canonical-system/architecture/CODE_AS_ORCHESTRATOR_v1.md
- Loop LaunchAgent: ~/Library/LaunchAgents/com.digitalmavericks.code-orchestrator.plist
- Digest LaunchAgent: ~/Library/LaunchAgents/com.digitalmavericks.code-morning-digest.plist
- First loop manifest above
- First digest sent to DC Slack at [time]
- Status: LIVE
```

---

## ANTI-STALL FOR YOU (the orchestrator)

You have full execution authority. You do not ask DC permission for:
- API key rotation, env var changes
- n8n workflow restarts via Elestio API
- Restarting ECHO's heartbeat workflow
- Browser-use to fix Asana / GHL / Slack admin tasks ECHO stalled on
- Creating Supabase rows, edge functions
- Updating echo.constitution row if Charter v4 isn't enforcing autonomy in practice

If a Type-1 irreversible decision arises (delete production data, send mass communication, move money over $100), escalate to DC's Slack DM with a 5-line decision card and wait for explicit approval.

**Pattern detection rules to enforce on ECHO:**
1. ECHO claims "blocked" without 2+ error signatures + 1+ remediation logged → REJECT, force re-execution
2. ECHO stalls >60 min on a task → re-issue with urgency tag + log warning
3. ECHO claims false blocker 3 times in 24 hours → escalate to DC + suggest Charter patch
4. ECHO writes "DC needs to do X" where X is something ECHO has authority for → REJECT, paste the corrective action

---

## DONE WHEN

After this first run completes:
- LaunchAgents loaded and verified via `launchctl list`
- First loop manifest appended to shared-state.md
- First digest delivered to DC Slack DM
- shared-state.md has a CODE-AS-ORCHESTRATOR DEPLOYED entry
- Wrapper scripts (`code-orchestrator-loop.sh`, `code-morning-digest.sh`) executable + tested
- Loop briefs (`CLAUDE_CODE_LOOP_BRIEF.md`, `CLAUDE_CODE_DIGEST_BRIEF.md`) written

After that you run forever. DC sleeps. DC wakes to digest. Cowork (the assistant DC talks to in chat) writes new briefs at his next session start, reviews what you shipped, never operates ECHO directly.

Begin Step 1.
