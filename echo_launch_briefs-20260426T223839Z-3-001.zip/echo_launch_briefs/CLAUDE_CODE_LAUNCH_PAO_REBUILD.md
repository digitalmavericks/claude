# Claude Code Launch · PAO_Rebuild + PM_Revamp Completion

**Mission:** Finish the Make.com → n8n Elestio migration that ECHO has been stalled on since April 16. Build the Doc Assembly Engine. Consolidate Google Ads M6+M7+M8. Migrate the 15 n8n Cloud workflows to Elestio. Run real smoketests on Image Pipeline AND Video Pipeline THROUGH n8n (not in your workspace). Write a manifest. Done.

**Estimated runtime:** 3-5 hours unattended.
**Output target:** All work pushed to live n8n Elestio + manifest at `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/echo_launch_briefs/PAO_REBUILD_MANIFEST.md` + log line in `shared-state.md`.

---

## CRITICAL OPERATING RULES — READ FIRST

### Rule 1 · The April 16 blockers doc is STALE

The `PAO-Andromeda_Build_ECHO_Action_Items_Blockers-Status_20260416` document at `https://docs.google.com/document/d/1zcMyqX_ttf8HYDoLySrlDom4F-9swvXG5K7Uuvl8EnE/edit` lists 9 "DC action items" — DC has confirmed **most are wrong** because ECHO's memory hasn't synced in 2 weeks. The corrections:

| Apr 16 doc says | DC's correction |
|---|---|
| Windsor.ai API key — DC must set | ECHO does this (browser-use API + her credit card) |
| Connect Facebook + Google Ads OAuth in Windsor | DONE 1 week ago |
| Add 9 Airtable Funnel Events fields | ECHO does this (agentic Airtable work) |
| Verify Replicate credential 8wghGI9QszxJnwLW | ECHO does this — DON'T claim DC blocker |
| Verify Google Docs OAuth (Iniesta/Izzy issue) | Old credentials already deleted |
| Verify Google Ads API credential | DONE yesterday — Code added missing management scopes during PAP-4 Help Wanted setup |
| VAPI / AL Pixels / Clickers-Openers decision | KEEP all — used by email system + AIO Signal pixels |

**Do NOT re-list any of these as DC blockers in your output. They are ECHO/Code execution work.**

### Rule 2 · Anti-stall blocked-claim gate

Before you write "I'm blocked" anywhere in the manifest or any commit message, you MUST have logged:
- **At least 2 distinct error signatures** (full error text, timestamp, the n8n node + workflow that produced them)
- **At least 1 remediation attempt** (what you tried, what happened, why it failed)

If you cannot produce both, you are NOT blocked. You are stalling. Keep working.

### Rule 3 · Smoketest through n8n. Period.

ECHO's failure pattern: she runs smoketests in her own workspace where everything works, then claims the pipeline is healthy. **Banned.** Every smoketest in this run must:
- Trigger via the n8n Elestio webhook URL
- Execute on the live n8n Elestio runtime
- Write its output to the actual production destination (Airtable / Google Drive / Supabase — whichever is canonical for that pipeline)
- Be verifiable in the n8n execution log with a green ✓

Workspace-side smoketests do not count. They go in the manifest as "NOT VALID — re-run through n8n."

### Rule 4 · Bias to action

You have full execution authority (per Charter v4 §1, deployed Apr 24). You do not ask DC permission for:
- API key creation, env var setting on Elestio
- Airtable schema changes
- n8n workflow imports, edits, activations
- Workflow deletions on Make.com
- Replicate / OpenAI / Anthropic / Google credential verification + recreation
- Subagent task delegation

If a real Type-1 irreversible decision arises (e.g., delete a production Make scenario before its replacement is verified), log a 5-line decision card in the manifest with: choice / reason / alternatives considered / risk / rollback path. Then proceed.

---

## SOURCE FILES TO READ BEFORE EXECUTION

Read all of these in this order. They are your full context.

1. `/Users/echo/Documents/Claude/Projects/ECHO/ECHO-AUTONOMY-CHARTER-v4.md` — your active identity + authority
2. Google Drive: `PAO-Amendment_Make-to-n8n-Migration-Track.md` (file id `1Mp5lGfcBBgMe7abX1TBfHRV5QYtGpAkO`) — the canonical migration spec with full per-workflow replacement table
3. Google Drive: `PAO-Creative-Pipeline-SOP-v2-2026-04-16.md` (file id `1VTzNQcSY7La7usVNSPxGUH0ouNPunb6sV1u6hVLADmk`) — current SOP
4. Google Drive: `PAO META ADS N8N Workflows.md` (file id `1rTxWjPyZ-dwzQcee7Feog9Df6Hzqb_67`, 127KB) — the n8n workflow inventory
5. Google Drive: `P0-MISSION-CRITICAL-PM-REVAMP.txt` (file id `1pI-Gg3LLDOwXiZqwrMu3hk39hbn3ks8z`, 41KB) — PM Revamp brief
6. Google Drive: `PAO-Execution-Plan-Redline.md` (file id `1gAcJbAMgpaB1UxkHLZ0la2PS3Lg-ckXB`) — current execution plan
7. Google Drive: `PAO-Andromeda-Week1-Table-Schemas copy.md` (file id `1R5i6koctnd8ckq0HJ34ZODIjf_-BMLvp`) — Airtable + Supabase schemas

Use the Google Drive MCP `read_file_content` tool with each fileId.

---

## EXECUTION SEQUENCE

### Phase 1 · Environment Verification (target: 15 min)

1. SSH into Elestio (or use the Elestio dashboard) and confirm the n8n env vars are set:
   - `WEBHOOK_URL=https://n8n-digitalmavericks-u48043.vm.elestio.app/`
   - `N8N_PROTOCOL=https`
   - `N8N_HOST=n8n-digitalmavericks-u48043.vm.elestio.app`
   - `N8N_PROXY_HOPS=1`
   - `WINDSOR_API_KEY` (verify it's set; if not, retrieve from `/Users/echo/Documents/Claude/Projects/ECHO/ECHO-CONFIG.md` or pull from 1Password vault, do NOT ask DC)
2. Verify Replicate credential `8wghGI9QszxJnwLW` is live in n8n. If broken, recreate using the API key from `ECHO-CONFIG.md`.
3. Verify Google Docs OAuth credential under DC's account (echo@digitalmavericksmedia.com or marketing@digitalmavericksmedia.com — which one is configured in ECHO-CONFIG.md is canonical).
4. Verify Anthropic, OpenAI, Gemini, Perplexity API keys all live in n8n credentials.
5. Add the 9 missing fields to the Airtable `Funnel Events` table in base `appDR4VrzSgTBXRyi`:
   - Spend (Currency), Revenue (Currency), Clicks (Number), Impressions (Number), Conversions (Number), Campaign (Single line text), Source (Single line text), Ad Set (Single line text), Date (Date)
6. Log all results in the manifest under "Phase 1 · Environment Verification."

### Phase 2 · Build the Doc Assembly Engine v1 (target: 45 min)

This is the keystone — 17 of 20 Make.com webhook calls are doc-assembly work. Build ONCE, reuse everywhere.

1. Create new n8n workflow `Doc Assembly Engine v1` in Elestio:
   - Trigger: Execute Workflow Trigger
   - Input fields: docTitle, docContent, templateDocId (optional), folderId, clientName
   - Node 1: IF templateDocId exists → Copy template doc, ELSE → Create blank doc
   - Node 2: Code Node — Convert markdown to Google Docs JSON (insert requests)
   - Node 3: Google Docs Batch Update (append formatted content)
   - Node 4: Set Node — Return { docUrl, docId, docTitle }
2. Smoketest with a dummy markdown payload. Verify the Google Doc gets created in the correct folder with proper formatting.
3. Save and activate.
4. Log the workflow ID in the manifest.

### Phase 3 · Make.com → n8n Migration (target: 90-120 min)

Per the migration spec, 10 Make scenarios remain. Execute in order:

**Sub-phase 3A · Doc-assembly replacements (6 scenarios) — uses Doc Assembly Engine v1**

| # | Make scenario | n8n target | Action |
|---|---|---|---|
| 1 | M2 · 1.2 Create Facebook Ads Report Document | Existing workflow 2a | Replace Make HTTP node with Execute Workflow → Doc Assembly Engine v1 |
| 2 | M3 · 2.1 Create FB Creative Strategy Report | Workflow 2b | Same |
| 3 | M4 · 1b.1 Create Funnel Report Document | Workflow 1c | Same |
| 4 | M5 · 1b.2 Create Funnel Creative Strategy | Workflow 2c | Same |
| 5 | M10 · 4.1 Custom Copy Ad Document Creation | Workflow 2.1 | 9 separate calls to Doc Assembly Engine v1 (one per content type) |
| 6 | M11 · 4.2 Create Market Research Document | Workflow 1d | Same |

For each: open the n8n workflow → find the HTTP Request node calling Make.com → replace with Execute Workflow node → wire to Doc Assembly Engine v1 → activate → smoketest with one real client record.

**Sub-phase 3B · Google Ads consolidation (M6+M7+M8 → 1 new workflow)**

Build new n8n workflow `Google Ads Consolidated v1`:
- Trigger: Schedule (per existing M6 cadence)
- Step 1: Pull Google Ads campaign attribution (replaces M6)
- Step 2: Pull ad group data (replaces M7)
- Step 3: Pull Google Assets (replaces M8)
- Step 4: Write to Airtable + Doc Assembly Engine for the strategy report
- Activate, smoketest, log workflow ID.

**Sub-phase 3C · Video creative analysis (M1) — inline replacement**

Workflow 1a (FB Ads Analytics) → replace Make.com video analysis call with:
- HTTP Request → Meta Graph API: `GET /{video_id}?fields=thumbnails`
- Code Node: extract thumbnail URL
- Airtable Update: write thumbnail URL to record

Activate, smoketest with one video creative.

**Sub-phase 3D · Make.com kill list**

After all 10 replacements verified live in n8n, on Make.com:
- Turn OFF the 10 SOP scenarios (do not delete yet — keep as 30-day rollback)
- Verify no other workflows still call Make.com webhooks
- Document the kill list in the manifest

### Phase 4 · n8n Cloud → Elestio Migration (target: 60-90 min)

15 workflows still on n8n Cloud. For each:

1. Export JSON from n8n Cloud
2. Run `replacewebhooks.py` to swap n8n Cloud URLs → Elestio URLs
3. Import to Elestio
4. Verify credentials are wired (recreate if missing)
5. Activate
6. Smoketest with one trigger event
7. Log result in manifest

Batch the 15 into 3 groups of 5 to keep cognitive load manageable. Log each batch separately.

### Phase 5 · Image Pipeline Smoketest (target: 30 min)

1. Trigger the Image Pipeline workflow via its n8n Elestio webhook URL (NOT in your workspace).
2. Pass it one real prompt from Ellis's 200-image batch backlog.
3. Verify:
   - Replicate credential fires successfully
   - Output image lands in the correct Google Drive folder
   - Airtable gets the URL + metadata
4. Log execution ID + Drive URL + Airtable record ID in manifest.
5. If anything fails, capture full error signature, attempt 1 remediation, then either retry-pass or log-blocked-with-evidence per Rule 2.

### Phase 6 · Video Pipeline Smoketest + Build Verification (target: 60 min)

Per the Apr 16 doc, "Video Pipeline (Section 5.2) — TBD, not yet built." First check whether it's been built since April 16 (search n8n for any workflow with "Video Pipeline" or "DC_Avatar_Video_Pipeline" in the name).

**If exists:** smoketest via webhook URL, same protocol as Phase 5.

**If not exists:** Build it per the SOP spec. Architecture:
- Trigger: Webhook (called by Workflow 1)
- Step 1: Pull video brief from Airtable
- Step 2: Generate audio + visual prompt sequence
- Step 3: Call DC_Avatar_Video_Pipeline (Drive folder ID `1NeSb7u83BAfNhYixCe9ZNGtVEgyULiXc`)
- Step 4: Render via Kling/VEO3 (whichever is the current production renderer)
- Step 5: Write final video URL to Airtable
- Activate + smoketest with one real brief.

Log: workflow ID, build status (existing-tested vs. newly-built-tested), execution ID, output Drive URL.

### Phase 7 · Manifest + State Sync

Write the manifest at `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/echo_launch_briefs/PAO_REBUILD_MANIFEST.md` with EXACTLY this structure:

```markdown
# PAO_Rebuild + PM_Revamp Manifest
**Run completed:** [timestamp]
**Total runtime:** [HH:MM:SS]
**API cost:** [estimate from token counts + Replicate runs]

## Phase 1 · Environment
- [ ] WEBHOOK_URL verified
- [ ] WINDSOR_API_KEY set
- [ ] Replicate credential verified
- [ ] Google Docs OAuth verified (account: ___)
- [ ] All 6 LLM API keys verified
- [ ] Airtable Funnel Events 9 fields added
Errors logged: [N] · Remediated: [N]

## Phase 2 · Doc Assembly Engine v1
- Workflow ID: ___
- Smoketest: [pass/fail · execution ID]

## Phase 3 · Make.com Migration
For each of M1, M2, M3, M4, M5, M6+M7+M8 consolidated, M10, M11:
- Replaced with: ___
- n8n workflow ID: ___
- Smoketest: [pass/fail · execution ID]
- Make scenario status: [OFF / pending kill]

## Phase 4 · n8n Cloud → Elestio
For each of 15 workflows:
- Original Cloud URL: ___
- Elestio import status: ___
- Webhooks rewritten: [yes/no]
- Credentials wired: [yes/no]
- Smoketest: [pass/fail · execution ID]

## Phase 5 · Image Pipeline
- Smoketest method: n8n Elestio webhook URL [confirmed not workspace]
- Execution ID: ___
- Output Drive URL: ___
- Airtable record ID: ___
- Result: [pass/fail]

## Phase 6 · Video Pipeline
- Build status: [existing/newly-built]
- Smoketest method: n8n Elestio webhook URL [confirmed not workspace]
- Execution ID: ___
- Output Drive URL: ___
- Result: [pass/fail]

## Aggregate Stats
- Total workflows migrated: [N]
- Total smoketests passed (in n8n): [N / total]
- Workspace-side smoketests run: SHOULD BE 0
- Real blocker count (with 2+ error signatures + 1 remediation): [N]
- False blocker count avoided: [N]

## Rollback Path
- Make.com scenarios kept OFF (not deleted) for 30-day rollback window
- n8n Cloud workflows still active for 1-week parallel run
- Doc Assembly Engine v1 backup export saved at: ___

## Issues for DC Review
[Only items that genuinely require DC's eyes go here. If everything ran cleanly,
 write: "No issues. PAO_Rebuild + PM_Revamp complete. All 25 workflows live on
 Elestio. Image + Video pipelines verified through n8n. Ready for production cutover."]
```

After the manifest is saved, append one line to `/Users/echo/Documents/Claude/Projects/ECHO/shared-memory/shared-state.md` under a new section:

```
## PAO_Rebuild + PM_Revamp Run [date]
COMPLETE · X/10 Make scenarios migrated · Y/15 n8n Cloud workflows on Elestio · Image pipeline pass/fail · Video pipeline pass/fail · 0 false blockers · manifest at [path]
```

Also update `shared-state.md` Known Issues section: remove the "Events API migration: Blocked until OpenClaw supports webhook mode" note IF it's been resolved by this run.

---

## ANTI-STALL RUN-TIME CHECKLIST (re-read every 30 min during the run)

- [ ] Am I waiting for DC permission on something I have authority to do? → STOP, execute it.
- [ ] Am I about to run a smoketest in my workspace? → STOP, route through n8n Elestio.
- [ ] Have I claimed "I'm blocked" without 2+ error signatures + 1 remediation logged? → STOP, retry or fix the gate violation.
- [ ] Am I re-reading the Apr 16 stale doc? → STOP, that doc is invalid. Read this brief instead.
- [ ] Am I asking the user to clarify scope mid-execution? → STOP, scope is locked. If genuinely ambiguous, log the assumption you're proceeding under in the manifest.

---

## DONE WHEN

All of:
- 25 workflows live on n8n Elestio (10 ex-Make + 15 ex-Cloud)
- Doc Assembly Engine v1 active and called by ≥6 parent workflows
- Image Pipeline smoketest passes via n8n Elestio webhook
- Video Pipeline either built-and-tested OR existing-and-tested via n8n Elestio webhook
- Manifest written with all 7 phases checked
- shared-state.md has the completion log line
- Zero entries in "Issues for DC Review" that are actually ECHO/Code execution items

Begin Phase 1. Do not stop until all 7 phases + manifest are done.
