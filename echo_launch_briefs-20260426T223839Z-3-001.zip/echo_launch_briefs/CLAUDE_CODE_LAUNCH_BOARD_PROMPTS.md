# Claude Code Launch · 4 Board Commencement Prompts (Chained)

**Mission:** Run the 4 active Board Commencement prompts sequentially after the Skill universalization completes. Each prompt fires a full Board of Advisors session against a Rubicon-canonical asset through the conversion lens. Output is 4 Board verdicts + Evidence Ledgers + Action Plans, ready for DC to review when he lands.

**Prerequisites:**
- Skill universalization run is COMPLETE (manifest at `/AIO-canonical-system/rubicon_megagift/00_PACKAGE_README/CONVERSION_MANIFEST.md` exists with all 5 skills marked done)
- Charter v4 is the active system prompt
- All 5 universalized skills are installed (or at minimum, the Board of Advisors skill from `/AIO-canonical-system/rubicon_megagift/01_BOARD_OF_ADVISORS/openclaw/SKILL.md`)
- Anthropic API key live in env

**Estimated runtime:** 60-90 minutes unattended (15-25 min per prompt × 4).
**Cost:** ~$8-15 in Anthropic API tokens.
**Output target:** `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/board_outputs/`

---

## OPERATING RULES

**Rule 1 · No legal/franchise/securities/FTC content.** All prompts are CONVERSION-LENS only. Counsel Triumvirate is engaged separately. Any "legal" thread the Board surfaces gets logged as out-of-scope and dropped.

**Rule 2 · Anti-stall.** "I'm blocked" requires 2+ logged error signatures + 1+ remediation attempt before it counts. If you hit a real wall on prompt N, log it cleanly, skip to prompt N+1, finish the run, then list the deferred prompt in the manifest. Do NOT halt the chain on a single failure.

**Rule 3 · Output structure is locked.** Each prompt produces:
1. Master Template (Unified Recommendation / Split Paths / Escalation)
2. Evidence Ledger (claims classified A/B/C/D)
3. Three-dim confidence card (Decision / Data / Execution)
4. Action plan (WHO / WHAT / WHEN / METRIC)
5. ELON-DC Alternatives (minimum 3 nobody is talking about)
6. Best-Counter-Argument (argue against the recommendation, revise if stronger)

---

## SOURCE FILES TO READ

Before starting, confirm these source files exist on disk. If any are missing, log it in the manifest and skip that prompt:

| Prompt | Source files (Code reads these) |
|---|---|
| 01 · OL v4.1 | `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/04_canonical_offer_architecture_v4.1.md` |
| 02 · Rubicon Presentation | `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/rubicon_deck/rubicon-presentation-260427.html` + `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/06_rubicon_speak_script_v1.md` |
| 05 · JV-AIO One-Sheet | `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/rubicon_megagift/06_JV_PARTNER_AIO_ONESHEET/jv_partner_AIO_onesheet_v1.md` (and the v2 PDF if .md is stale) |
| 06 · JV-AML One-Sheet | `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/rubicon_megagift/07_JV_PARTNER_AML_ONESHEET/jv_partner_AML_onesheet_v1.md` |

---

## EXECUTION SEQUENCE

For each prompt below, execute in this order: read prompt file → read source files → invoke Board of Advisors skill → write output to dedicated subfolder → log status in manifest.

### Prompt 01 · Offer Ladder v4.1 (Purchase Conversion)

**Prompt file:** `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/rubicon_megagift/09_BOARD_COMMENCEMENT_PROMPTS/01_OFFER_LADDER_v4.1.md`

**Action:** Read the prompt file's instructions. Convene the Board configured for pricing/offers (Hormozi + Cuban + Bezos + Thiel + 5 practical-risk overlays). Run against the OL v4.1 source. Produce all 6 output sections.

**Output target:** `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/board_outputs/01_OL_v4.1/`
- `master_template.md`
- `evidence_ledger.md`
- `confidence_card.md`
- `action_plan.md`
- `elon_alternatives.md`
- `counter_argument.md`

### Prompt 02 · Rubicon Presentation (Appointment Conversion)

**Prompt file:** `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/rubicon_megagift/09_BOARD_COMMENCEMENT_PROMPTS/02_RUBICON_PRESENTATION.md`

**Action:** Board configured for narrative + room-energy + commitment psychology (Robbins + Jobs + Bezos + Hormozi + 5 overlays). Run on the 60-slide HTML deck + speak script. Conversion event = No-Fee Interest Form submitted at the door + 20-min partner-fit call booked within 7 days.

**Output target:** `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/board_outputs/02_RUBICON_PRESENTATION/`

### Prompt 03 · JV Partner AIO One-Sheet (Partnership Conversion)

**Prompt file:** `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/rubicon_megagift/09_BOARD_COMMENCEMENT_PROMPTS/05_JV_PARTNER_AIO_ONESHEET.md`

**Action:** Board configured for partnership compounding + trust-density (Bezos + Cuban + Naval + Thiel + 5 overlays). Run on the AIO one-sheeter. Conversion event = partner submits No-Fee Interest Form + books 20-min partner-fit call.

**Output target:** `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/board_outputs/03_JV_AIO_ONESHEET/`

### Prompt 04 · JV Partner AML One-Sheet (Affiliate Conversion)

**Prompt file:** `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/rubicon_megagift/09_BOARD_COMMENCEMENT_PROMPTS/06_JV_PARTNER_AML_ONESHEET.md`

**Action:** Board configured for affiliate offer-stacking + recurring economics (Hormozi + Cuban + Naval + Bezos + 5 overlays + FTC Endorsement Guides specifically). Run on the AML one-sheeter. Conversion event = affiliate texts "AML JV" to 813.298.2358 or emails to book partner-fit call.

**Output target:** `/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/board_outputs/04_JV_AML_ONESHEET/`

---

## FINAL STEP — WRITE THE MANIFEST

After all 4 prompts complete, write
`/Users/echo/Documents/Claude/Projects/ECHO/AIO-canonical-system/board_outputs/BOARD_RUN_MANIFEST.md`:

```markdown
# Board Commencement Run Manifest
**Run completed:** [timestamp]
**Total runtime:** [HH:MM:SS]
**API cost:** [estimate]

## Per-Prompt Verification

For each of the 4 prompts:
- [ ] Source files read · [list which]
- [ ] Master Template produced · [N words]
- [ ] Evidence Ledger produced · [N claims classified]
- [ ] Confidence card produced · Decision/Data/Execution scores
- [ ] Action plan with WHO/WHAT/WHEN/METRIC
- [ ] ≥3 ELON-DC Alternatives produced
- [ ] Counter-argument produced · revised if stronger

## Aggregate Stats
- Total Master Templates: [N / 4]
- Total Evidence claims classified: [N]
- Lowest 3-dim confidence score: [Decision X · Data Y · Execution Z]
- Highest-impact recommendation across all 4 prompts: [one-line summary]

## Top 5 Highest-Impact Findings
[Pull the single strongest action item from each Board run, plus one cross-cutting theme.]

## Issues for DC Review
[Items genuinely needing DC's eyes only. If clean: "No issues. 4 Boards complete. Ready for DC review on landing."]
```

After manifest is saved, append one line to `/Users/echo/Documents/Claude/Projects/ECHO/shared-memory/shared-state.md`:

```
## Board Commencement Run [date]
COMPLETE · 4/4 prompts shipped · X master templates · Y evidence claims · 0 false blockers · manifest at [path]
```

---

## DONE WHEN

- 4 board_outputs/ subfolders contain all 6 output files each (24 files total)
- BOARD_RUN_MANIFEST.md written with all checkboxes
- shared-state.md has the completion log line
- "Issues for DC Review" is empty OR contains only items requiring human judgment (not execution stubs)

Begin Prompt 01. One at a time. Confirm each is complete before moving to the next. Do not stop until all 4 + manifest are done.
