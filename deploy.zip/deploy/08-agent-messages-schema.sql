-- ============================================================================
-- ECHO Agent Messages Bus - Schema v1.0
-- Effective: 2026-04-21
-- Purpose: Durable async message channel between claude_cowork and echo agents.
-- Complements the bidirectional MCP servers. Bus handles 90% of traffic
-- (state handoffs, batch context sync, archival). MCP handles 10%
-- (synchronous typed request/response).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- Enum guards are inline CHECK constraints rather than PostgreSQL enums
-- so amendments do not require pg_enum migrations.
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS agent_messages (
    id                BIGSERIAL PRIMARY KEY,

    -- Idempotency. Sender generates a uuidv4 or sha256 of canonical payload.
    -- Duplicate inserts return 409 to the caller, do not raise an exception
    -- that would block the bus.
    idempotency_key   TEXT NOT NULL UNIQUE,

    -- Agent identity. Enforced at the enum level AND at RLS level.
    from_agent        TEXT NOT NULL CHECK (from_agent IN ('claude_cowork','echo')),
    to_agent          TEXT NOT NULL CHECK (to_agent   IN ('claude_cowork','echo')),

    -- Priority drives read-SLA and fan-out behavior.
    -- P0: operational incident, read <=5 min, ack required.
    -- P1: strategic handoff, read <=1 hour.
    -- P2: routine status, read <=4 hours.
    -- P3: archival, no ack.
    priority          TEXT NOT NULL CHECK (priority IN ('P0','P1','P2','P3')),

    subject           TEXT NOT NULL,
    payload           JSONB NOT NULL,

    -- Protocol version locks sender and receiver to a compatible schema.
    protocol_version  TEXT NOT NULL DEFAULT 'v1.0',

    -- Hop counter prevents A->B->A->B infinite loops.
    -- Hard cap at 3 hops. Anything higher is auto-rejected by trigger below.
    hop_count         INT  NOT NULL DEFAULT 0,

    status            TEXT NOT NULL DEFAULT 'pending'
                        CHECK (status IN ('pending','delivered','ack','failed','expired')),

    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    delivered_at      TIMESTAMPTZ,
    ack_at            TIMESTAMPTZ,
    expires_at        TIMESTAMPTZ NOT NULL DEFAULT (now() + INTERVAL '24 hours'),

    -- Correlation id links request/response pairs across the bus.
    correlation_id    TEXT,

    -- Error taxonomy. See §3.4 of the Architecture Decision doc for codes.
    error_code        TEXT,
    error_detail      TEXT
);

-- ----------------------------------------------------------------------------
-- Indexes sized for expected load:
-- - ~1-10 msgs/min steady state
-- - ~100 msgs/min burst during incident
-- ----------------------------------------------------------------------------

CREATE INDEX IF NOT EXISTS idx_agent_messages_to_pending
    ON agent_messages (to_agent, status, priority DESC, created_at)
    WHERE status = 'pending';

CREATE INDEX IF NOT EXISTS idx_agent_messages_correlation
    ON agent_messages (correlation_id)
    WHERE correlation_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_agent_messages_expiry_sweep
    ON agent_messages (expires_at)
    WHERE status = 'pending';

-- ----------------------------------------------------------------------------
-- Hop-limit guard trigger.
-- Any INSERT with hop_count >= 3 is rejected and logged.
-- Logging goes to blueprint_audit_log with actor='agent_bus_loop_guard'.
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION agent_messages_hop_guard() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.hop_count >= 3 THEN
        INSERT INTO blueprint_audit_log (actor, action, subject, payload, at)
        VALUES (
            'agent_bus_loop_guard',
            'reject_hop_limit',
            COALESCE(NEW.subject, 'unknown'),
            jsonb_build_object(
                'from_agent', NEW.from_agent,
                'to_agent', NEW.to_agent,
                'hop_count', NEW.hop_count,
                'correlation_id', NEW.correlation_id
            ),
            now()
        );
        RAISE EXCEPTION 'E_HOP_LIMIT: hop_count=% exceeded max 3', NEW.hop_count
            USING ERRCODE = 'P0001';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_agent_messages_hop_guard ON agent_messages;
CREATE TRIGGER trg_agent_messages_hop_guard
    BEFORE INSERT ON agent_messages
    FOR EACH ROW EXECUTE FUNCTION agent_messages_hop_guard();

-- ----------------------------------------------------------------------------
-- Row-level security.
-- Each agent can:
--   - SELECT rows where from_agent = caller OR to_agent = caller
--   - INSERT rows where from_agent = caller
--   - UPDATE rows where to_agent = caller, but only these columns:
--       status, delivered_at, ack_at, error_code, error_detail
-- No DELETE. Cleanup is handled by expiry sweep function.
-- ----------------------------------------------------------------------------

ALTER TABLE agent_messages ENABLE ROW LEVEL SECURITY;

-- Caller identity is read from the custom session variable app.agent_id.
-- Both agents set this at connection time via SET app.agent_id = 'echo';

CREATE POLICY agent_messages_select ON agent_messages
    FOR SELECT
    USING (
        from_agent = current_setting('app.agent_id', true)
        OR to_agent = current_setting('app.agent_id', true)
    );

CREATE POLICY agent_messages_insert ON agent_messages
    FOR INSERT
    WITH CHECK (
        from_agent = current_setting('app.agent_id', true)
    );

CREATE POLICY agent_messages_update ON agent_messages
    FOR UPDATE
    USING (
        to_agent = current_setting('app.agent_id', true)
    )
    WITH CHECK (
        to_agent = current_setting('app.agent_id', true)
    );

-- ----------------------------------------------------------------------------
-- Expiry sweep.
-- Runs every 15 minutes via pg_cron (or external cron calling this function).
-- Marks pending messages past expires_at as 'expired'.
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION agent_messages_expire_sweep() RETURNS INT AS $$
DECLARE
    expired_count INT;
BEGIN
    WITH expired AS (
        UPDATE agent_messages
        SET status = 'expired',
            error_code = 'E_EXPIRED',
            error_detail = 'Auto-expired by sweep at ' || now()::text
        WHERE status = 'pending'
          AND expires_at < now()
        RETURNING id
    )
    SELECT COUNT(*) INTO expired_count FROM expired;

    IF expired_count > 0 THEN
        INSERT INTO blueprint_audit_log (actor, action, subject, payload, at)
        VALUES (
            'agent_bus_expiry_sweep',
            'expire_stale_messages',
            'agent_messages',
            jsonb_build_object('count', expired_count),
            now()
        );
    END IF;

    RETURN expired_count;
END;
$$ LANGUAGE plpgsql;

-- ----------------------------------------------------------------------------
-- Helper view for shadow-mode dashboards.
-- ----------------------------------------------------------------------------

CREATE OR REPLACE VIEW agent_messages_health AS
SELECT
    date_trunc('hour', created_at) AS hour,
    from_agent,
    to_agent,
    priority,
    status,
    COUNT(*) AS msg_count,
    AVG(EXTRACT(EPOCH FROM (delivered_at - created_at))) FILTER (WHERE delivered_at IS NOT NULL) AS avg_delivery_sec,
    AVG(EXTRACT(EPOCH FROM (ack_at - delivered_at))) FILTER (WHERE ack_at IS NOT NULL) AS avg_ack_sec,
    COUNT(*) FILTER (WHERE error_code IS NOT NULL) AS error_count
FROM agent_messages
WHERE created_at > now() - INTERVAL '7 days'
GROUP BY 1, 2, 3, 4, 5
ORDER BY 1 DESC, 4 DESC;

-- ----------------------------------------------------------------------------
-- Acceptance smoke test.
-- Run after deployment. Should insert one row, update it, verify RLS.
-- ----------------------------------------------------------------------------

-- As 'claude_cowork':
-- SET app.agent_id = 'claude_cowork';
-- INSERT INTO agent_messages (idempotency_key, from_agent, to_agent, priority, subject, payload)
-- VALUES ('smoke-test-001', 'claude_cowork', 'echo', 'P2', 'smoke_test', '{"ping":"hello"}'::jsonb);
--
-- As 'echo':
-- SET app.agent_id = 'echo';
-- UPDATE agent_messages SET status = 'delivered', delivered_at = now()
--   WHERE idempotency_key = 'smoke-test-001';
-- UPDATE agent_messages SET status = 'ack', ack_at = now()
--   WHERE idempotency_key = 'smoke-test-001';
--
-- Verify hop-limit trigger:
-- SET app.agent_id = 'claude_cowork';
-- INSERT INTO agent_messages (idempotency_key, from_agent, to_agent, priority, subject, payload, hop_count)
-- VALUES ('smoke-test-002', 'claude_cowork', 'echo', 'P2', 'hop_test', '{}'::jsonb, 3);
-- -- Expect: ERROR E_HOP_LIMIT

-- ============================================================================
-- End of schema v1.0
-- ============================================================================
