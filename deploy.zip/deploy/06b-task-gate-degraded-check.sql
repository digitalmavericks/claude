-- ECHO Blueprint v1.0 — Task Gate degraded-mode pre-flight (PLAY 2, v1.1)
--
-- Inserted before the claim/advance/close switch in the task-gate n8n workflow.
-- Returns zero rows if the Edge Function fallback has fired in the last 5 minutes,
-- signalling the Task Gate to respond HTTP 503 { ok: false, error: "degraded_mode_active" }.
--
-- Rationale: during degraded mode ECHO may be reading a stale constitution.
-- External-state writes (Meta / Asana / Airtable) against stale creds can
-- cross-contaminate accounts. Refuse writes until n8n primary is healthy.
--
-- ECHO's task-gate skill already treats 503 as a refusal and aborts the claim.

SELECT 1 AS ok
WHERE NOT EXISTS (
    SELECT 1
    FROM blueprint_audit_log
    WHERE actor = 'edge_function_fallback'
      AND at > now() - INTERVAL '5 minutes'
);

-- Expected behavior:
--   Returns 1 row  → primary is healthy, proceed with claim/advance/close
--   Returns 0 rows → degraded mode active, task-gate returns HTTP 503
