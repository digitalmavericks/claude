#!/usr/bin/env bash
# ECHO session-start hook — SHADOW variant (2026-04-20 11:00 ET → 2026-04-21 11:00 ET)
#
# Behavior:
#   1. PRIMARY: POST to the n8n Constitution Enforcer webhook (authoritative).
#   2. SHADOW: compare the webhook response against the four legacy markdown files
#      (SOUL.md, HEARTBEAT.md, IDENTITY.md, CREDENTIAL_MAP.md) and log every
#      field-level diff to blueprint_audit_log via n8n `/webhook/shadow-diff-log`.
#   3. Diff-log failure MUST NOT abort session start (curl || true).
#   4. Exits 42 on webhook failure. Exits 43 on schema failure. Exits 0 on success.
#
# Replace the production hook at ~/.openclaw/hooks/echo-session-start.sh with this
# file at 2026-04-20 11:00 ET. Restore the v1.1 variant at 2026-04-22 12:00 ET.

set -euo pipefail

CONSTITUTION_URL="${ECHO_CONSTITUTION_URL:-https://n8n-digitalmavericks-u48043.vm.elestio.app/webhook/constitution-enforcer}"
DIFF_LOG_URL="${ECHO_SHADOW_DIFF_LOG_URL:-${CONSTITUTION_URL%/constitution-enforcer}/shadow-diff-log}"
MARKDOWN_ROOT="${OPENCLAW_WORKSPACE:-$HOME/.openclaw/workspace}"
OUTPUT_FILE="${OPENCLAW_SESSION_BRIEFING:-/tmp/echo-briefing.json}"
SESSION_ID="${OPENCLAW_SESSION_ID:-$(uuidgen)}"

export MARKDOWN_ROOT OUTPUT_FILE

# ---------- PRIMARY: webhook fetch ----------
HTTP_CODE=$(curl -sS --max-time 15 -X POST "${CONSTITUTION_URL}" \
  -H "Content-Type: application/json" \
  -d "{\"session_id\":\"${SESSION_ID}\",\"requested_at\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" \
  -o "${OUTPUT_FILE}" -w "%{http_code}") || HTTP_CODE="000"

if [[ "${HTTP_CODE}" != "200" ]]; then
  echo "FATAL: constitution webhook returned HTTP ${HTTP_CODE}. Aborting session." >&2
  exit 42
fi

# Schema verification — refuse to start without a credential_resolver map
if ! jq -e '.constitution.credential_resolver' "${OUTPUT_FILE}" >/dev/null 2>&1; then
  echo "FATAL: briefing payload missing .constitution.credential_resolver. Aborting." >&2
  exit 43
fi

# ---------- SHADOW: markdown diff ----------
DIFF_PAYLOAD=$(python3 - <<'PYEOF'
import json, os, re, sys

brief = json.load(open(os.environ["OUTPUT_FILE"]))
constitution = brief.get("constitution", {})
md_root = os.environ["MARKDOWN_ROOT"]
diffs = []

# Field -> (file, regex, flags)
FIELD_MAP = {
    "meta_app_id":     ("CREDENTIAL_MAP.md", r"meta[_ ]app[_ ]id[:\s]+([0-9]+)",        re.I),
    "meta_app_name":   ("CREDENTIAL_MAP.md", r"meta[_ ]app[_ ]name[:\s]+([A-Za-z0-9\-_]+)", re.I),
    "asana_webhook_id":("CREDENTIAL_MAP.md", r"asana[_ ]webhook[_ ]id[:\s]+([A-Za-z0-9]+)",  re.I),
    "identity_name":   ("IDENTITY.md",       r"name[:\s]+([A-Za-z0-9 \-_]+)",             re.I),
    "identity_role":   ("IDENTITY.md",       r"role[:\s]+([A-Za-z0-9 \-_]+)",             re.I),
    "heartbeat_rev":   ("HEARTBEAT.md",      r"revision[:\s]+([A-Za-z0-9\.\-]+)",          re.I),
    "soul_mission":    ("SOUL.md",           r"mission[:\s]+\"?([^\"\n]+)\"?",              re.I),
}

for field, (filename, pattern, flags) in FIELD_MAP.items():
    path = os.path.join(md_root, filename)
    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except FileNotFoundError:
        diffs.append({"key": field, "webhook": constitution.get(field), "markdown": None, "reason": "markdown_missing"})
        continue
    m = re.search(pattern, text, flags)
    md_val = m.group(1).strip() if m else None
    wh_val = constitution.get(field)
    # Normalize for string comparison
    if md_val is not None and wh_val is not None and str(md_val) != str(wh_val):
        diffs.append({"key": field, "webhook": wh_val, "markdown": md_val})
    elif md_val is None and wh_val is not None:
        diffs.append({"key": field, "webhook": wh_val, "markdown": None, "reason": "markdown_field_missing"})

print(json.dumps(diffs))
PYEOF
)

# Log diffs (success OR empty-array) to audit endpoint — failure to log must NOT abort
curl -sS --max-time 5 -X POST "${DIFF_LOG_URL}" \
  -H "Content-Type: application/json" \
  -d "{\"session_id\":\"${SESSION_ID}\",\"diffs\":${DIFF_PAYLOAD},\"at\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" \
  >/dev/null 2>&1 || true

exit 0
