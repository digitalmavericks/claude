---
name: constitution-enforcer
description: Machine-enforced replacement for SOUL.md, HEARTBEAT.md, IDENTITY.md, and CREDENTIAL_MAP.md. On every ECHO session start, fetch the live constitution + active tasks + recent failures from the Supabase-backed webhook and inject as system context. On fetch failure, ABORT the session. Zero markdown fallback. Zero written-rule drift.
version: 1.0
effective: 2026-04-20
owner: echo
criticality: critical
---

# Constitution Enforcer — Contract

ECHO's operating constitution lives in Supabase `immutable_decisions`, not in markdown files. The Constitution Enforcer workflow is the only authorized read path. This skill documents the contract so every ECHO session and every workflow that needs a constitutional value knows where to look.

## Why this exists

SOUL.md + HEARTBEAT.md + IDENTITY.md + CREDENTIAL_MAP.md failed because:
1. Markdown is session-local. New sessions don't read them first.
2. Markdown is human-editable. Drift is inevitable.
3. Markdown has no query surface. Workflows can't pull a single value.

The enforcer fixes all three: single source, machine-queried, audit-logged.

## Endpoint

`POST https://n8n-digitalmavericks-u48043.vm.elestio.app/webhook/constitution-enforcer`

## Request

```json
{
  "session_id": "openclaw-session-uuid",
  "requested_at": "2026-04-20T09:15:00Z"
}
```

## Response

```json
{
  "constitution": {
    "credential_resolver": "op_cli_service_account",
    "meta_app_id": "1270528905051701",
    "meta_app_name": "ECHO-DMM",
    "asana_webhook_id": "nAC6RsmUdVYiujot",
    "image_canonical_store": "supabase_creative_source_assets",
    "markdown_constitution": "RETIRED_2026_04_20",
    "task_gate_required": "true",
    "google_drive_ingest_role": "operator_inbox_only_not_canonical"
  },
  "active_tasks": [
    { "id": "uuid", "external_id": "asana:...", "title": "...", "status": "in_progress", "last_action_at": "..." }
  ],
  "recent_failures": [
    { "id": "exec-id", "workflowId": "wf-id", "startedAt": "...", "error": "..." }
  ],
  "generated_at": "2026-04-20T09:15:02Z",
  "schema_version": "1.0"
}
```

## Usage

### OpenClaw session start

Configured via `hooks.on_session_start` → `echo-session-start.sh` → writes briefing to `${OPENCLAW_SESSION_BRIEFING}` → OpenClaw injects as `system_context`.

### n8n workflow pre-flight

Any workflow that needs a constitutional value queries Postgres directly:

```sql
SELECT value FROM immutable_decisions WHERE key = 'meta_app_id' AND locked = true;
```

Do NOT hardcode these values in workflow nodes. Always read-at-runtime.

## Banned behaviors

- Never read SOUL.md, HEARTBEAT.md, IDENTITY.md, or CREDENTIAL_MAP.md from any workflow, skill, or hook. They are retired.
- Never hardcode `meta_app_id`, `credential_resolver`, `asana_webhook_id`, or any other constitutional value.
- Never mutate `immutable_decisions` via ad-hoc SQL. Changes require a logged `blueprint_audit_log` entry and Board approval.
- Never silently continue if the enforcer returns non-200. Abort.

## Test (smoke)

```bash
curl -sS -X POST https://n8n-digitalmavericks-u48043.vm.elestio.app/webhook/constitution-enforcer \
  -H "Content-Type: application/json" \
  -d '{"session_id":"smoke-001","requested_at":"2026-04-20T09:15:00Z"}' | jq '.constitution'
```

Expect all 8 keys present, `markdown_constitution == "RETIRED_2026_04_20"`.
