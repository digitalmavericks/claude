---
name: task-gate
description: MANDATORY gate for any ECHO action that changes external state (Asana, Airtable, Meta, Google Ads, Supabase writes, Slack posts, ad spend, workflow imports). Before acting, claim the task via the task-gate webhook. During work, advance with evidence. At end, close with final_status. If the gate refuses, STOP and report. Never execute external-state changes without a live task_sync_state row.
version: 1.0
effective: 2026-04-20
owner: echo
criticality: critical
---

# Task Gate — Contract

Every ECHO action that changes external state MUST pass through the Task Gate. The gate enforces that a `task_sync_state` row exists in Supabase before the action begins. No row, no action — structurally, not behaviorally.

## Why this exists

Written rules ("always check before acting") have failed 33 times. The gate is architectural: if the row doesn't exist, the webhook refuses the claim, and the downstream action has no authorization token to proceed. Planning-only mode becomes structurally impossible because a plan with no `claim` call leaves no trace — and any downstream workflow that requires a `task_sync_state.id` will reject the payload.

## Endpoint

`POST https://n8n-digitalmavericks-u48043.vm.elestio.app/webhook/task-gate`

## Actions

### 1. claim — before any external-state change

```json
{
  "action": "claim",
  "external_id": "asana:1209876543210",
  "title": "Fix PAP-1 Meta account ID in Andromeda Config",
  "source": "asana",
  "plan_ref": "plan-2026-04-20-airtable-fix"
}
```

Returns: `{ ok: true, action: "claim", row: { id, external_id, status: "in_progress" } }`. Hold the `id` for every `advance` and `close` call in this task.

### 2. advance — during work, log evidence

```json
{
  "action": "advance",
  "external_id": "asana:1209876543210",
  "evidence": {
    "step": "fetched_airtable_record",
    "record_id": "rec1e2vlT0zz57DPO",
    "observed_value": "137419436693632",
    "expected_value": "1374194366936320"
  }
}
```

Call advance on every meaningful step. Evidence merges into the `evidence` jsonb column. This is the audit trail.

### 3. close — at end, with final status

```json
{
  "action": "close",
  "external_id": "asana:1209876543210",
  "final_status": "done",
  "evidence": {
    "final_value": "1374194366936320",
    "verified_via": "airtable_get_record",
    "completed_at": "2026-04-20T14:32:00Z"
  }
}
```

`final_status` must be one of: `done`, `blocked`, `killed`.

## Refusal cases — STOP if any of these fire

- HTTP 4xx/5xx from the gate → abort, report to `#echo-ops`, do not retry blindly.
- `ok: false` in response → read the error, do not loop.
- Claim succeeds but external_id already `done` → task is finished; do not reopen without explicit DC approval.
- Network timeout >15s → treat as refusal. Fail loud.

## Banned behaviors

- Never execute an external-state change before `claim` returns 200.
- Never skip `advance` calls to "save time." The evidence trail is the product.
- Never close with `done` if any sub-step failed. Use `blocked` with a `blocked_reason`.
- Never manually insert into `task_sync_state` — always route through the webhook.

## Test (smoke)

```bash
curl -sS -X POST https://n8n-digitalmavericks-u48043.vm.elestio.app/webhook/task-gate \
  -H "Content-Type: application/json" \
  -d '{"action":"claim","external_id":"test:smoke-001","title":"Smoke test","source":"manual"}'
```

Expect HTTP 200 + `row.status == "in_progress"`.
