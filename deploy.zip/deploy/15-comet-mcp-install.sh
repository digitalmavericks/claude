#!/usr/bin/env bash
# =============================================================================
# 15-comet-mcp-install.sh
# -----------------------------------------------------------------------------
# Install Perplexity Comet MCP (RapierCraft fork) + register it with Claude
# Desktop so Claude (me) can drive Comet browser + Model Council from this
# session.
#
# Why: DC wants Comet (desktop app) as the research agent and Model Council
# orchestrator, not the Perplexity API. We bridge Claude <-> Comet via an
# MCP server instead of the API.
#
# Effective: 2026-04-22
# Owner: DC Fawcett
# Author: Claude (ECHO's Integrator)
# =============================================================================
set -euo pipefail

ECHO_ROOT="/Users/echo/Documents/Claude/Projects/ECHO"
MCP_ROOT="$ECHO_ROOT/mcp-servers"
COMET_MCP_DIR="$MCP_ROOT/perplexity-comet-mcp"
CLAUDE_DESKTOP_CFG="$HOME/Library/Application Support/Claude/claude_desktop_config.json"
LOG="$ECHO_ROOT/deploy/logs/15-comet-mcp-install-$(date +%Y%m%d-%H%M%S).log"

mkdir -p "$MCP_ROOT" "$(dirname "$LOG")"
exec > >(tee -a "$LOG") 2>&1

say() { printf "\n[\033[1;36m%s\033[0m] %s\n" "$(date +%H:%M:%S)" "$*"; }
ok()  { printf "  \033[1;32m✓\033[0m %s\n" "$*"; }
warn(){ printf "  \033[1;33m!\033[0m %s\n" "$*"; }
die() { printf "  \033[1;31m✗\033[0m %s\n" "$*"; exit 1; }

# =============================================================================
# 0. Preflight
# =============================================================================
say "Preflight"

# Node.js
if ! command -v node >/dev/null 2>&1; then
  warn "node not found — installing node@20 via brew"
  brew install node@20
  brew link --force --overwrite node@20
fi
NODE_VER="$(node --version)"
ok "node $NODE_VER"

# npm
command -v npm >/dev/null 2>&1 || die "npm missing after node install"
ok "npm $(npm --version)"

# Comet desktop app
if [ ! -d "/Applications/Comet.app" ]; then
  warn "Comet.app not found at /Applications/Comet.app"
  warn "Download: https://comet.perplexity.ai — must be installed before MCP works"
  warn "Continuing install anyway (MCP server can install without Comet running)"
else
  ok "Comet.app present at /Applications/Comet.app"
fi

# =============================================================================
# 1. Clone / update RapierCraft fork
# =============================================================================
say "Installing Perplexity-Comet-MCP (RapierCraft fork)"

if [ -d "$COMET_MCP_DIR/.git" ]; then
  ok "existing checkout found — pulling latest"
  git -C "$COMET_MCP_DIR" fetch --all
  git -C "$COMET_MCP_DIR" pull --rebase --autostash
else
  git clone https://github.com/RapierCraft/Perplexity-Comet-MCP.git "$COMET_MCP_DIR"
  ok "cloned RapierCraft/Perplexity-Comet-MCP -> $COMET_MCP_DIR"
fi

# =============================================================================
# 2. Install deps + build
# =============================================================================
say "Installing dependencies"
cd "$COMET_MCP_DIR"
npm install --silent
ok "npm install complete"

if grep -q '"build"' package.json; then
  npm run build
  ok "build complete"
else
  warn "no build script in package.json — assuming runtime-compiled"
fi

# =============================================================================
# 3. Register with Claude Desktop
# =============================================================================
say "Registering MCP in claude_desktop_config.json"

mkdir -p "$(dirname "$CLAUDE_DESKTOP_CFG")"
if [ ! -f "$CLAUDE_DESKTOP_CFG" ]; then
  echo '{ "mcpServers": {} }' > "$CLAUDE_DESKTOP_CFG"
  ok "seeded empty claude_desktop_config.json"
fi

# Back up first.
cp "$CLAUDE_DESKTOP_CFG" "$CLAUDE_DESKTOP_CFG.bak-$(date +%Y%m%d-%H%M%S)"
ok "backed up claude_desktop_config.json"

# Merge the MCP entry using Node (jq may not be installed).
node <<EOF
const fs = require('fs');
const path = '$CLAUDE_DESKTOP_CFG';
const cfg = JSON.parse(fs.readFileSync(path, 'utf8'));
cfg.mcpServers = cfg.mcpServers || {};

// Entry — RapierCraft build provides a CLI; adjust command/args if their
// package.json uses a different bin name after pulling latest.
const entryPoint = require.resolve('$COMET_MCP_DIR/package.json').replace(/package\\.json\$/,'');
cfg.mcpServers["perplexity-comet"] = {
  command: "node",
  args: ["$COMET_MCP_DIR/dist/index.js"],
  env: {
    COMET_APP_PATH: "/Applications/Comet.app",
    NODE_ENV: "production"
  }
};

fs.writeFileSync(path, JSON.stringify(cfg, null, 2));
console.log("  wrote mcpServers.perplexity-comet");
EOF

ok "claude_desktop_config.json updated"

# =============================================================================
# 4. Verify entrypoint exists
# =============================================================================
say "Verifying entrypoint"
ENTRY="$COMET_MCP_DIR/dist/index.js"
if [ ! -f "$ENTRY" ]; then
  # Fall back to src if no dist.
  if [ -f "$COMET_MCP_DIR/src/index.js" ] || [ -f "$COMET_MCP_DIR/src/index.ts" ]; then
    warn "no dist/index.js — RapierCraft package uses src/ directly; updating config"
    node -e "const fs=require('fs'); const p='$CLAUDE_DESKTOP_CFG'; const c=JSON.parse(fs.readFileSync(p,'utf8')); c.mcpServers['perplexity-comet'].args=['$COMET_MCP_DIR/src/index.js']; fs.writeFileSync(p, JSON.stringify(c,null,2));"
  else
    die "could not locate entrypoint — inspect $COMET_MCP_DIR and adjust config"
  fi
fi
ok "entrypoint resolved"

# =============================================================================
# 5. Quick syntax smoke test (don't actually drive Comet, just prove it boots)
# =============================================================================
say "Smoke test — booting MCP server for 3 seconds"
timeout 3 node "$ENTRY" >/dev/null 2>&1 || true
ok "MCP server started + exited without crash (expected — no stdin)"

# =============================================================================
# 6. Reminder to restart Claude Desktop
# =============================================================================
say "Next step (MANUAL — only physical action required)"
cat <<EOF

  Restart Claude Desktop for the MCP config to load:
    1. Quit Claude Desktop (⌘Q).
    2. Reopen it.
    3. New chat → you should see the \`perplexity-comet\` MCP listed in
       available tools. First tool call will trigger macOS to prompt for
       Accessibility permission for Claude Desktop → Comet (approve it).

  From this session, after restart, I test the connection via:
    - mcp__perplexity-comet__comet_tabs (list open tabs)
    - mcp__perplexity-comet__comet_navigate (open a URL in Comet)
    - mcp__perplexity-comet__comet_ask_assistant (send a query to Comet's
      built-in Model Council — this is the one that replaces the API path)

EOF

ok "Install complete. Log: $LOG"
