-- ECHO Blueprint v1.0 — SEPI Bootstrap Schema Patch (PLAY 3)
--
-- Apply AFTER deploy/01-schema.sql. Idempotent. Required for:
--   1. Tagging synthetic rows so live-learning consumers can filter them out.
--   2. Making deploy/07-sepi-bootstrap.py idempotent (ON CONFLICT upserts).
--   3. Enabling future embedding-model migrations without orphaning data.

BEGIN;

-- sepi_reflections: add source + embedding_model tagging
ALTER TABLE sepi_reflections
    ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'live',
    ADD COLUMN IF NOT EXISTS embedding_model text;

-- Idempotency key for the bootstrap script
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'uq_sr_workflow_prompt'
    ) THEN
        ALTER TABLE sepi_reflections
            ADD CONSTRAINT uq_sr_workflow_prompt UNIQUE (workflow, prompt);
    END IF;
END$$;

-- Filter index for live-only SEPI consumers
CREATE INDEX IF NOT EXISTS idx_sr_source ON sepi_reflections(source);

-- sepi_vector_bank: track which embedding model produced the vector
ALTER TABLE sepi_vector_bank
    ADD COLUMN IF NOT EXISTS embedding_model text;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'uq_svb_reflection'
    ) THEN
        ALTER TABLE sepi_vector_bank
            ADD CONSTRAINT uq_svb_reflection UNIQUE (reflection_id);
    END IF;
END$$;

COMMIT;

-- Verification
SELECT
    'sepi_reflections' AS tbl,
    COUNT(*) FILTER (WHERE column_name = 'source') AS has_source,
    COUNT(*) FILTER (WHERE column_name = 'embedding_model') AS has_embedding_model
FROM information_schema.columns
WHERE table_name = 'sepi_reflections'
UNION ALL
SELECT
    'sepi_vector_bank',
    0,
    COUNT(*) FILTER (WHERE column_name = 'embedding_model')
FROM information_schema.columns
WHERE table_name = 'sepi_vector_bank';
