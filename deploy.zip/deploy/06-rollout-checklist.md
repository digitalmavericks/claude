# ECHO Master Blueprint v1.0 — Rollout Checklist

**Effective:** Monday, April 20, 2026 — 09:00 to 15:00 ET
**Owner:** DC Fawcett (final approval) + ECHO (execution) + Lorenzo (observer)
**Posture:** One-shot architectural lock. Hard rollback gate at T+3h.

---

## Pre-Flight (08:30–09:00 ET)

| # | Check | Owner | Pass Criteria |
|---|-------|-------|---------------|
| P1 | Confirm `n8n-digitalmavericks-u48043.vm.elestio.app` reachable | ECHO | `curl -I` returns 200/401 |
| P2 | Confirm Supabase at `echos-mac-mini-1.tail074467.ts.net:4242` reachable | ECHO | `psql -c "SELECT 1"` returns 1 |
| P3 | Confirm `op` CLI headless access works | ECHO | `op item get "Meta Ads Token" --field credential` returns token, no GUI prompt |
| P4 | Snapshot current n8n workflow list | ECHO | Saved to `/deploy/snapshots/n8n-workflows-pre-lock.json` |
| P5 | Snapshot current Supabase schema | ECHO | Saved to `/deploy/snapshots/supabase-schema-pre-lock.sql` |
| P6 | Confirm Asana webhook `nAC6RsmUdVYiujot` active; dead listener `CfS6vMFI9VdREekj` confirmed dead | ECHO | REST check on both |

**Gate:** All 6 pass. Any fail → abort rollout, report to `#echo-ops`.

---

## Phase 1 — Schema Lock (09:00–09:30 ET)

| # | Step | Command | Pass Criteria |
|---|------|---------|---------------|
| 1.1 | Apply schema | `psql -f deploy/01-schema.sql` | Smoke test returns 6 rows, `immutable_decisions` count = 8 |
| 1.2 | Verify seed rows (by key, not just count) | `SELECT count(*) FROM immutable_decisions WHERE locked = true AND key IN ('credential_resolver','meta_app_id','meta_app_name','asana_webhook_id','image_canonical_store','markdown_constitution','task_gate_required','google_drive_ingest_role');` | Returns 8 |
| 1.3 | Verify views | `SELECT * FROM v_tasks_pm_overview;` + `SELECT * FROM v_tasks_blocked_or_at_risk;` | Both return (empty is fine) |
| 1.4 | Confirm pgvector extension | `\dx vector` | Listed |

**Gate:** T+30min. Schema live. Any SQL error → ROLLBACK transaction, abort.

---

## Phase 2 — Workflow Import (09:30–10:30 ET)

| # | Step | Command | Pass Criteria |
|---|------|---------|---------------|
| 2.1 | Import constitution-enforcer | n8n UI import `deploy/02-constitution-enforcer.json` | Workflow created, credentials linked |
| 2.2 | Activate constitution-enforcer | `PATCH /api/v1/workflows/{id} {"active": true}` | `active: true` |
| 2.3 | Import task-gate | n8n UI import `deploy/03-task-gate.json` | Workflow created, credentials linked |
| 2.4 | Activate task-gate | `PATCH /api/v1/workflows/{id} {"active": true}` | `active: true` |
| 2.5 | Smoke test constitution | `curl -X POST .../webhook/constitution-enforcer ...` | HTTP 200, 8 constitution keys present |
| 2.6 | Smoke test task-gate claim | `curl -X POST .../webhook/task-gate -d '{"action":"claim","external_id":"test:smoke-001",...}'` | HTTP 200, row inserted |
| 2.7 | Smoke test task-gate advance | `curl -X POST ... -d '{"action":"advance","external_id":"test:smoke-001",...}'` | HTTP 200, evidence merged |
| 2.8 | Smoke test task-gate close | `curl -X POST ... -d '{"action":"close","external_id":"test:smoke-001","final_status":"done",...}'` | HTTP 200, status=done |

**Gate:** T+1.5h. Both workflows active and smoke-passing. Any failure → deactivate, debug, retry once, else abort.

---

## Phase 3 — OpenClaw Hook (10:30–11:30 ET)

| # | Step | Command | Pass Criteria |
|---|------|---------|---------------|
| 3.1 | Copy session-start hook | `cp deploy/04-session-start.sh ~/.openclaw/hooks/echo-session-start.sh && chmod +x` | File exists, executable |
| 3.2 | Apply openclaw.json patch | Merge `deploy/05-openclaw.json.patch` into `~/.openclaw/config/openclaw.json` | Config validates, `on_session_start_on_error: abort` set |
| 3.3 | Test hook manually | `bash ~/.openclaw/hooks/echo-session-start.sh` | Exit 0, briefing file written, jq parse succeeds |
| 3.4 | Open fresh OpenClaw session | Start new session | Session loads with constitution as system_context (visible in first-turn reasoning) |
| 3.5 | Retire markdown files | `mv ~/.openclaw/workspace/SOUL.md /archived/SOUL.md.retired-2026-04-20` (repeat for HEARTBEAT, IDENTITY, CREDENTIAL_MAP) | Files archived, no longer present at live path |

**Gate:** T+2.5h. Fresh session proves constitution injection works. Any failure → revert openclaw.json, restore markdown files, abort.

---

## Phase 4 — Skills Registration (11:30–12:30 ET)

| # | Step | Command | Pass Criteria |
|---|------|---------|---------------|
| 4.1 | Install task-gate skill | Copy `deploy/skills/task-gate/` to OpenClaw skills dir | Skill discoverable |
| 4.2 | Install constitution-enforcer skill | Copy `deploy/skills/constitution-enforcer/` | Skill discoverable |
| 4.3 | Dry-run task-gate from ECHO | Issue ECHO command that requires state change; observe claim → advance → close sequence | All 3 calls succeed, row visible in `task_sync_state` |

**Gate:** T+3h. **HARD ROLLBACK GATE.** If ECHO cannot successfully claim/advance/close a test task, STOP. Revert Phase 3 (markdown restore + openclaw.json revert). Schedule post-mortem before retry.

---

## Phase 5 — Meta Credential Purge (12:30–13:30 ET)

| # | Step | Command | Pass Criteria |
|---|------|---------|---------------|
| 5.1 | List all Meta creds in n8n | `GET /api/v1/credentials?type=facebookGraphApi` | List of 4: ECHO-DMM, Izzy, Acc2, Acc3 |
| 5.2 | Audit workflow references | For each non-ECHO-DMM cred, find workflows using it | List produced |
| 5.3 | Repoint workflows to ECHO-DMM | PATCH each workflow's credential ref | All pointed to ECHO-DMM |
| 5.4 | Delete Izzy, Acc2, Acc3 creds | `DELETE /api/v1/credentials/{id}` | Only ECHO-DMM remains |
| 5.5 | Smoke test one repointed workflow | Trigger `1a. Facebook Ads Analytics` via DMM-1 | Row appears in Airtable |

**Gate:** T+4.5h. Any repointed workflow fails → revert that workflow's cred, keep the offending source cred alive temporarily, flag for Lorenzo.

---

## Phase 6 — Airtable Fixes + Asana Cleanup (13:30–14:30 ET)

| # | Step | Pass Criteria |
|---|------|---------------|
| 6.1 | Fix PAP-1 Meta account ID → `1374194366936320` | Airtable record `rec1e2vlT0zz57DPO` shows full 16-digit value |
| 6.2 | Verify TikTok account ID → `7541010467230351377` | Config table shows full 19-digit value |
| 6.3 | Verify Campaigns table exists in Airtable Conversions AI Ad System | Table present with full field set |
| 6.4 | Confirm dead Asana listener `CfS6vMFI9VdREekj` fully dead | `GET /webhooks/{id}` returns 404 or `active: false` |
| 6.5 | Repoint 38 Asana webhooks to `nAC6RsmUdVYiujot` using the script in `ECHO-Elon-Level-Execution-Package-April-20-2026.md` Section E.1 (curl loop that lists, filters, and PATCHes each) | List shows all 38 pointed to correct receiver; old listener `CfS6vMFI9VdREekj` has zero references |

**Gate:** T+5.5h. All Airtable fixes applied. Asana duplicate firing risk eliminated.

---

## Phase 7 — Acceptance + Sign-Off (14:30–15:00 ET)

| # | Step | Pass Criteria |
|---|------|---------------|
| 7.1 | Run PAP BrandDNA PASS/WATCH/FAIL batch tagging | Results written to Supabase, completion posted to `#echo-ops` |
| 7.2 | Trigger PAP-1 and PAP-4 through `1a. Facebook Ads Analytics` | Rows appear in Airtable Conversions AI Ad System → FB Campaigns |
| 7.3 | Verify Mission Control has Supabase image review links | PM tab `creative-source-assets` column populated |
| 7.4 | DC sign-off | "Ship-it" posted in `#echo-ops` |

---

## Rollback Plan (if any HARD GATE fails)

1. **Deactivate both n8n workflows** — constitution-enforcer + task-gate → `active: false`.
2. **Revert openclaw.json** — restore pre-lock version from `/deploy/snapshots/openclaw.json.pre-lock`.
3. **Restore markdown files** — `mv /archived/SOUL.md.retired-2026-04-20 ~/.openclaw/workspace/SOUL.md` (repeat).
4. **Do NOT drop Supabase tables** — schema is idempotent and harmless. Leave in place.
5. **Do NOT revert credential purge** — if Phase 5 completed, keep it. It's a net win.
6. **Post-mortem in `#echo-ops`** within 24h. Root cause + fix before retry.

---

## Signatures

- [ ] ECHO — pre-flight clean
- [ ] DC — go/no-go at 09:00 ET
- [ ] ECHO — T+3h gate passed
- [ ] DC — ship-it at 15:00 ET
