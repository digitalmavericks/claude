#!/usr/bin/env python3
"""
ECHO SEPI Synthetic Bootstrap.

Seeds sepi_reflections + sepi_vector_bank with the 33 documented ECHO failures
from the Apr 19 operational plan so the IVFFlat index is warm on Day 1 and
cosine-similarity queries return non-empty results from boot.

Idempotent on (workflow, prompt) — safe to re-run. Requires:
  - SUPABASE_DATABASE_URL  (Postgres connection string, service role)
  - OPENAI_API_KEY
  - deploy/data/apr-19-failures.json (curate before running)

Credentials live in ECHO-CONFIG.md at /Users/echo/Documents/Claude/Projects/ECHO/.
Paste the two env values from there before running.

Usage:
    export SUPABASE_DATABASE_URL="<paste from ECHO-CONFIG.md → SUPABASE → DATABASE_URL>"
    export OPENAI_API_KEY="<paste from ECHO-CONFIG.md → OPENAI → API_KEY>"
    python3 deploy/07-sepi-bootstrap.py

Exits non-zero on any row failure. The operator should run the §4.6 verification
SQL after this script completes successfully.
"""

import json
import os
import sys
import time

import psycopg2
from psycopg2.extras import execute_values
from openai import OpenAI

EMBEDDING_MODEL = "text-embedding-3-small"
EMBEDDING_DIM = 1536
FAILURES_FILE = os.environ.get("ECHO_FAILURES_JSON", "deploy/data/apr-19-failures.json")
RATE_LIMIT_DELAY_SEC = 0.1


def main() -> int:
    db_url = os.environ.get("SUPABASE_DATABASE_URL")
    if not db_url:
        print("FATAL: SUPABASE_DATABASE_URL not set", file=sys.stderr)
        return 2
    if not os.environ.get("OPENAI_API_KEY"):
        print("FATAL: OPENAI_API_KEY not set", file=sys.stderr)
        return 2

    if not os.path.exists(FAILURES_FILE):
        print(f"FATAL: failures file not found: {FAILURES_FILE}", file=sys.stderr)
        return 2

    with open(FAILURES_FILE, "r", encoding="utf-8") as f:
        failures = json.load(f)

    if not isinstance(failures, list) or not failures:
        print("FATAL: failures.json is empty or not a list", file=sys.stderr)
        return 2

    required_fields = {"workflow", "prompt", "output", "metric_delta"}
    for i, f in enumerate(failures):
        missing = required_fields - set(f.keys())
        if missing:
            print(f"FATAL: failures[{i}] missing fields: {missing}", file=sys.stderr)
            return 2

    print(f"Seeding {len(failures)} synthetic reflections using model {EMBEDDING_MODEL}...")

    client = OpenAI()
    conn = psycopg2.connect(db_url)
    conn.autocommit = False

    try:
        with conn.cursor() as cur:
            for idx, failure in enumerate(failures, 1):
                # Upsert reflection
                cur.execute(
                    """
                    INSERT INTO sepi_reflections
                        (workflow, prompt, output, outcome, metric_delta, source, embedding_model)
                    VALUES
                        (%s, %s, %s, 'loss', %s, 'synthetic_bootstrap', %s)
                    ON CONFLICT (workflow, prompt) DO UPDATE SET
                        output = EXCLUDED.output,
                        metric_delta = EXCLUDED.metric_delta,
                        embedding_model = EXCLUDED.embedding_model
                    RETURNING id
                    """,
                    (
                        failure["workflow"],
                        failure["prompt"],
                        failure["output"],
                        failure["metric_delta"],
                        EMBEDDING_MODEL,
                    ),
                )
                reflection_id = cur.fetchone()[0]

                # Embed the output field — it carries the most semantic signal
                resp = client.embeddings.create(
                    model=EMBEDDING_MODEL,
                    input=failure["output"],
                )
                embedding = resp.data[0].embedding

                if len(embedding) != EMBEDDING_DIM:
                    raise RuntimeError(
                        f"Unexpected embedding dimension: {len(embedding)} != {EMBEDDING_DIM}"
                    )

                cur.execute(
                    """
                    INSERT INTO sepi_vector_bank
                        (reflection_id, embedding, embedding_model)
                    VALUES
                        (%s, %s::vector, %s)
                    ON CONFLICT (reflection_id) DO UPDATE SET
                        embedding = EXCLUDED.embedding,
                        embedding_model = EXCLUDED.embedding_model
                    """,
                    (reflection_id, embedding, EMBEDDING_MODEL),
                )

                print(f"  [{idx}/{len(failures)}] {failure['workflow']} — reflection_id={reflection_id}")
                time.sleep(RATE_LIMIT_DELAY_SEC)

        conn.commit()
    except Exception as e:
        conn.rollback()
        print(f"FATAL: {e}", file=sys.stderr)
        return 1
    finally:
        conn.close()

    print(f"Seeded {len(failures)} synthetic reflections with embeddings.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
