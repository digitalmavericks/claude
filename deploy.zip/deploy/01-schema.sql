-- ECHO Master Blueprint v1.0 — Canonical Supabase Schema
-- Run in Supabase SQL editor OR via `supabase db push`
-- Effective: 2026-04-20
-- Idempotent: safe to re-run

BEGIN;

-- 1. Constitution
CREATE TABLE IF NOT EXISTS immutable_decisions (
  id serial PRIMARY KEY,
  key text UNIQUE NOT NULL,
  value text NOT NULL,
  locked boolean NOT NULL DEFAULT true,
  source text NOT NULL DEFAULT 'board',
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by text NOT NULL DEFAULT 'system'
);
CREATE INDEX IF NOT EXISTS idx_id_locked ON immutable_decisions(locked) WHERE locked = true;

INSERT INTO immutable_decisions (key, value, source) VALUES
  ('credential_resolver', 'op_cli_service_account', 'blueprint_v1'),
  ('meta_app_id', '1270528905051701', 'blueprint_v1'),
  ('meta_app_name', 'ECHO-DMM', 'blueprint_v1'),
  ('asana_webhook_id', 'nAC6RsmUdVYiujot', 'blueprint_v1'),
  ('image_canonical_store', 'supabase_creative_source_assets', 'blueprint_v1'),
  ('markdown_constitution', 'RETIRED_2026_04_20', 'blueprint_v1'),
  ('task_gate_required', 'true', 'blueprint_v1'),
  ('google_drive_ingest_role', 'operator_inbox_only_not_canonical', 'blueprint_v1')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now();

-- 2. Task Gate (unifies deprecated Phase 8 `entities`)
CREATE TABLE IF NOT EXISTS task_sync_state (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  external_id text UNIQUE,
  title text NOT NULL,
  source text NOT NULL,
  owner text NOT NULL DEFAULT 'echo',
  status text NOT NULL CHECK (status IN ('queued','in_progress','blocked','awaiting_review','done','killed')),
  plan_ref text,
  evidence jsonb,
  first_action_at timestamptz,
  last_action_at timestamptz,
  blocked_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_tss_status ON task_sync_state(status);
CREATE INDEX IF NOT EXISTS idx_tss_owner_status ON task_sync_state(owner, status);
CREATE INDEX IF NOT EXISTS idx_tss_source ON task_sync_state(source);

-- 3. Views
CREATE OR REPLACE VIEW v_tasks_pm_overview AS
  SELECT status, count(*) AS n, min(created_at) AS oldest
  FROM task_sync_state
  GROUP BY status;

CREATE OR REPLACE VIEW v_tasks_blocked_or_at_risk AS
  SELECT id, external_id, title, source, status, blocked_reason,
         EXTRACT(EPOCH FROM (now() - last_action_at))/60 AS minutes_since_action
  FROM task_sync_state
  WHERE status IN ('blocked','in_progress')
    AND (last_action_at IS NULL OR last_action_at < now() - interval '30 minutes')
  ORDER BY last_action_at ASC NULLS FIRST;

-- 4. Task comments
CREATE TABLE IF NOT EXISTS task_comments (
  id bigserial PRIMARY KEY,
  task_id uuid NOT NULL REFERENCES task_sync_state(id) ON DELETE CASCADE,
  author text NOT NULL,
  body text NOT NULL,
  external_comment_id text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_tc_task ON task_comments(task_id);

-- 5. SEPI scaffold (Phase 2 — empty-safe now)
CREATE TABLE IF NOT EXISTS sepi_reflections (
  id bigserial PRIMARY KEY,
  workflow text NOT NULL,
  prompt text NOT NULL,
  output text NOT NULL,
  outcome text CHECK (outcome IN ('win','loss','neutral')),
  metric_delta numeric,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Note: vector extension must be enabled OUTSIDE this transaction.
-- On Supabase, enable via Dashboard → Database → Extensions → vector (or run
-- `CREATE EXTENSION IF NOT EXISTS vector;` as a standalone statement BEFORE this file).
CREATE TABLE IF NOT EXISTS sepi_vector_bank (
  id bigserial PRIMARY KEY,
  reflection_id bigint REFERENCES sepi_reflections(id) ON DELETE CASCADE,
  embedding vector(1536),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_svb_embedding ON sepi_vector_bank
  USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- 6. Audit
CREATE TABLE IF NOT EXISTS blueprint_audit_log (
  id bigserial PRIMARY KEY,
  actor text NOT NULL,
  action text NOT NULL,
  subject text,
  payload jsonb,
  at timestamptz NOT NULL DEFAULT now()
);

COMMIT;

-- Smoke test
SELECT 'immutable_decisions' AS tbl, count(*) FROM immutable_decisions
UNION ALL SELECT 'task_sync_state', count(*) FROM task_sync_state
UNION ALL SELECT 'task_comments', count(*) FROM task_comments
UNION ALL SELECT 'sepi_reflections', count(*) FROM sepi_reflections
UNION ALL SELECT 'sepi_vector_bank', count(*) FROM sepi_vector_bank
UNION ALL SELECT 'blueprint_audit_log', count(*) FROM blueprint_audit_log;
