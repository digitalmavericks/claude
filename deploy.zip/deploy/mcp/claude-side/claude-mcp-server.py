#!/usr/bin/env python3
# ============================================================================
# claude-mcp-server.py  v0.1 (skeleton)
# Effective: 2026-04-22 (scheduled ship)
# ----------------------------------------------------------------------------
# Purpose: Expose six deterministic tools from Claude Cowork to ECHO.
#          Tools run locally, do NOT call the Anthropic API. Zero token cost
#          for ECHO to consume these.
# Transport: stdio (local only — ECHO invokes subprocess on same host).
# Auth: none (local IPC). If moved to HTTP, add X-Agent-Bus-Secret.
# Rate limits: per-tool 100/hour, global 500/hour. 429 returned on breach.
# ----------------------------------------------------------------------------
# Tool catalog:
#   1. read_blueprint_context(key)                 — pull blueprint section by key
#   2. query_audit_log(filter_dict, limit)         — structured SELECT on blueprint_audit_log
#   3. get_recent_failures(since_iso)              — list last N failures with source
#   4. score_artifact_against_rubric(artifact, id) — local rubric scorer
#   5. diff_two_files(path_a, path_b)              — unified diff, line-numbered
#   6. send_message_to_claude(priority, payload)   — inserts into agent_messages bus
# ----------------------------------------------------------------------------
# Dependencies:
#   pip install mcp psycopg2-binary
# ============================================================================

from __future__ import annotations

import asyncio
import difflib
import hashlib
import json
import os
import sys
import time
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

try:
    from mcp.server import Server  # type: ignore
    from mcp.server.stdio import stdio_server  # type: ignore
    from mcp.types import Tool, TextContent  # type: ignore
except ImportError:
    print("ERROR: mcp package not installed. Run: pip install mcp", file=sys.stderr)
    sys.exit(1)

try:
    import psycopg2  # type: ignore
    from psycopg2.extras import RealDictCursor  # type: ignore
except ImportError:
    print("ERROR: psycopg2 not installed. Run: pip install psycopg2-binary", file=sys.stderr)
    sys.exit(1)


# ============================================================================
# Config
# ============================================================================

BLUEPRINT_ROOT = Path(os.environ.get(
    "ECHO_BLUEPRINT_ROOT",
    "/Users/echo/Documents/Claude/Projects/ECHO"
))
SUPABASE_DSN = os.environ.get("ECHO_SUPABASE_DSN", "")  # required for DB-touching tools
AGENT_ID = "claude_cowork"

PER_TOOL_BUDGET = 100   # calls per hour per tool
GLOBAL_BUDGET   = 500   # calls per hour total
RATE_WINDOW_SEC = 3600


# ============================================================================
# Rate limiter (in-memory sliding window; process-local)
# ============================================================================

class RateLimiter:
    def __init__(self) -> None:
        self._per_tool: dict[str, deque[float]] = defaultdict(deque)
        self._global: deque[float] = deque()

    def check(self, tool_name: str) -> tuple[bool, str]:
        now = time.time()
        cutoff = now - RATE_WINDOW_SEC

        # Prune
        while self._global and self._global[0] < cutoff:
            self._global.popleft()
        dq = self._per_tool[tool_name]
        while dq and dq[0] < cutoff:
            dq.popleft()

        if len(self._global) >= GLOBAL_BUDGET:
            return False, f"E_RATE_LIMIT: global budget {GLOBAL_BUDGET}/hr exhausted"
        if len(dq) >= PER_TOOL_BUDGET:
            return False, f"E_RATE_LIMIT: {tool_name} budget {PER_TOOL_BUDGET}/hr exhausted"

        self._global.append(now)
        dq.append(now)
        return True, "ok"


limiter = RateLimiter()


# ============================================================================
# Helpers
# ============================================================================

def db_conn():
    if not SUPABASE_DSN:
        raise RuntimeError("ECHO_SUPABASE_DSN env var required for DB tools")
    return psycopg2.connect(SUPABASE_DSN, cursor_factory=RealDictCursor)


def _json_safe(obj: Any) -> Any:
    if isinstance(obj, (datetime,)):
        return obj.isoformat()
    if isinstance(obj, dict):
        return {k: _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_json_safe(v) for v in obj]
    return obj


def _error(code: str, message: str, **extra) -> str:
    return json.dumps({"ok": False, "error_code": code, "error": message, **extra})


def _ok(data: Any) -> str:
    return json.dumps({"ok": True, "data": _json_safe(data)})


# ============================================================================
# Tool implementations
# ============================================================================

async def tool_read_blueprint_context(key: str) -> str:
    """
    Retrieve a named section from the ECHO blueprint.
    Supported keys include: architecture, dual_mcp, agent_bus, asana, rubrics,
    avatars, and any filename under BLUEPRINT_ROOT without the extension.
    """
    ok, msg = limiter.check("read_blueprint_context")
    if not ok:
        return _error("E_RATE_LIMIT", msg)

    # Map keys to candidate files. First match wins.
    candidates = [
        BLUEPRINT_ROOT / f"{key}.md",
        BLUEPRINT_ROOT / f"ECHO-{key}.md",
        BLUEPRINT_ROOT / f"ECHO-{key}-v1.0.md",
        BLUEPRINT_ROOT / f"ECHO-{key.replace('_','-').title()}-v1.0.md",
    ]
    for path in candidates:
        if path.exists() and path.is_file():
            content = path.read_text(encoding="utf-8")
            return _ok({
                "key": key,
                "path": str(path),
                "length_chars": len(content),
                "content": content[:50000],  # hard cap per call
                "truncated": len(content) > 50000,
            })
    return _error("E_NOT_FOUND", f"No blueprint file matched key={key}",
                  searched=[str(p) for p in candidates])


async def tool_query_audit_log(filter_dict: dict, limit: int = 50) -> str:
    """
    SELECT from blueprint_audit_log with allowlisted filters.
    filter_dict keys supported: actor, action, subject, since_iso, until_iso.
    """
    ok, msg = limiter.check("query_audit_log")
    if not ok:
        return _error("E_RATE_LIMIT", msg)

    if limit > 500:
        return _error("E_SCHEMA", f"limit max is 500, got {limit}")

    where = []
    params: list[Any] = []
    for field in ("actor", "action", "subject"):
        if field in filter_dict and filter_dict[field]:
            where.append(f"{field} = %s")
            params.append(filter_dict[field])
    if "since_iso" in filter_dict and filter_dict["since_iso"]:
        where.append("at >= %s")
        params.append(filter_dict["since_iso"])
    if "until_iso" in filter_dict and filter_dict["until_iso"]:
        where.append("at <= %s")
        params.append(filter_dict["until_iso"])

    where_sql = (" WHERE " + " AND ".join(where)) if where else ""
    sql = f"""
        SELECT id, actor, action, subject, payload, at
        FROM blueprint_audit_log
        {where_sql}
        ORDER BY at DESC
        LIMIT %s
    """
    params.append(limit)

    try:
        with db_conn() as conn, conn.cursor() as cur:
            cur.execute(sql, params)
            rows = cur.fetchall()
        return _ok({"count": len(rows), "rows": list(rows)})
    except Exception as e:
        return _error("E_DOWNSTREAM", f"audit log query failed: {e}")


async def tool_get_recent_failures(since_iso: str | None = None) -> str:
    """
    Return last N failure records with source URLs.
    Sources: blueprint_audit_log, n8n_executions (error), agent_messages (failed).
    """
    ok, msg = limiter.check("get_recent_failures")
    if not ok:
        return _error("E_RATE_LIMIT", msg)

    if not since_iso:
        since_iso = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()

    try:
        with db_conn() as conn, conn.cursor() as cur:
            cur.execute("""
                SELECT
                    id,
                    actor,
                    action,
                    subject,
                    payload,
                    at,
                    'blueprint_audit_log' AS source_table
                FROM blueprint_audit_log
                WHERE action LIKE '%fail%' OR action LIKE '%error%' OR action LIKE '%reject%'
                  AND at >= %s
                UNION ALL
                SELECT
                    id,
                    from_agent AS actor,
                    'bus_message_failed' AS action,
                    subject,
                    jsonb_build_object('error_code', error_code, 'error_detail', error_detail) AS payload,
                    created_at AS at,
                    'agent_messages' AS source_table
                FROM agent_messages
                WHERE status IN ('failed','expired')
                  AND created_at >= %s
                ORDER BY at DESC
                LIMIT 200
            """, (since_iso, since_iso))
            rows = cur.fetchall()
        return _ok({"count": len(rows), "since": since_iso, "rows": list(rows)})
    except Exception as e:
        return _error("E_DOWNSTREAM", f"failures query failed: {e}")


async def tool_score_artifact_against_rubric(artifact: str, rubric_id: str) -> str:
    """
    Local deterministic rubric scorer. Returns per-dimension 0-100 scores.
    Stub v0.1: length/keyword heuristic. v0.2 will load actual rubrics from
    BLUEPRINT_ROOT/rubrics/{rubric_id}.json.
    """
    ok, msg = limiter.check("score_artifact_against_rubric")
    if not ok:
        return _error("E_RATE_LIMIT", msg)

    rubric_path = BLUEPRINT_ROOT / "rubrics" / f"{rubric_id}.json"
    if not rubric_path.exists():
        return _error("E_NOT_FOUND", f"rubric {rubric_id} not found at {rubric_path}")

    rubric = json.loads(rubric_path.read_text(encoding="utf-8"))
    scores: dict[str, int] = {}
    for dim in rubric.get("dimensions", []):
        name = dim["name"]
        min_words = dim.get("min_words", 50)
        keywords = dim.get("keywords", [])
        word_count = len(artifact.split())
        kw_hits = sum(1 for k in keywords if k.lower() in artifact.lower())
        kw_ratio = (kw_hits / max(1, len(keywords))) if keywords else 1.0
        length_score = min(100, int(100 * word_count / max(1, min_words)))
        scores[name] = int(0.6 * kw_ratio * 100 + 0.4 * length_score)

    overall = sum(scores.values()) // max(1, len(scores))
    pass_threshold = rubric.get("pass_threshold", 85)
    return _ok({
        "rubric_id": rubric_id,
        "overall": overall,
        "dimensions": scores,
        "pass_threshold": pass_threshold,
        "passes": overall >= pass_threshold,
    })


async def tool_diff_two_files(path_a: str, path_b: str) -> str:
    """Unified diff of two files, line-numbered. Read-only."""
    ok, msg = limiter.check("diff_two_files")
    if not ok:
        return _error("E_RATE_LIMIT", msg)

    pa, pb = Path(path_a), Path(path_b)
    for p in (pa, pb):
        if not p.exists() or not p.is_file():
            return _error("E_NOT_FOUND", f"{p} is not a readable file")
        if not str(p).startswith(str(BLUEPRINT_ROOT)):
            return _error("E_FORBIDDEN", f"{p} is outside BLUEPRINT_ROOT")

    a_lines = pa.read_text(encoding="utf-8").splitlines(keepends=True)
    b_lines = pb.read_text(encoding="utf-8").splitlines(keepends=True)
    diff = list(difflib.unified_diff(a_lines, b_lines,
                                     fromfile=str(pa), tofile=str(pb), n=3))
    return _ok({
        "path_a": str(pa),
        "path_b": str(pb),
        "hash_a": hashlib.sha256(pa.read_bytes()).hexdigest()[:16],
        "hash_b": hashlib.sha256(pb.read_bytes()).hexdigest()[:16],
        "diff_lines": len(diff),
        "diff": "".join(diff)[:100000],  # 100KB cap
    })


async def tool_send_message_to_claude(priority: str, payload: dict,
                                      subject: str = "echo_to_claude",
                                      correlation_id: str | None = None) -> str:
    """
    Insert a message into agent_messages bound for claude_cowork.
    ECHO uses this for asynchronous handoffs. Bypasses the n8n relay —
    direct SQL insert with from_agent='echo' (RLS-enforced).
    """
    ok, msg = limiter.check("send_message_to_claude")
    if not ok:
        return _error("E_RATE_LIMIT", msg)

    if priority not in ("P0", "P1", "P2", "P3"):
        return _error("E_SCHEMA", f"priority must be P0-P3, got {priority}")

    payload_str = json.dumps(payload, sort_keys=True, default=str)
    payload_hash = hashlib.sha256(payload_str.encode()).hexdigest()[:16]
    iso_date = datetime.now(timezone.utc).date().isoformat()
    idem = f"echo:{subject}:{payload_hash}:{iso_date}"

    try:
        with db_conn() as conn, conn.cursor() as cur:
            cur.execute("SET app.agent_id = 'echo'")
            cur.execute("""
                INSERT INTO agent_messages
                    (idempotency_key, from_agent, to_agent, priority, subject, payload, correlation_id)
                VALUES (%s, 'echo', 'claude_cowork', %s, %s, %s::jsonb, %s)
                ON CONFLICT (idempotency_key) DO NOTHING
                RETURNING id, created_at, expires_at
            """, (idem, priority, subject, payload_str, correlation_id))
            row = cur.fetchone()
            conn.commit()

        if row is None:
            return _ok({"duplicate": True, "idempotency_key": idem})
        return _ok({
            "message_id": row["id"],
            "idempotency_key": idem,
            "created_at": row["created_at"],
            "expires_at": row["expires_at"],
        })
    except Exception as e:
        return _error("E_DOWNSTREAM", f"bus insert failed: {e}")


# ============================================================================
# MCP server wiring
# ============================================================================

server = Server("claude-cowork")


@server.list_tools()  # type: ignore[misc]
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="read_blueprint_context",
            description="Retrieve a named section from the ECHO blueprint by key (e.g. 'dual_mcp', 'asana', 'architecture').",
            inputSchema={
                "type": "object",
                "properties": {"key": {"type": "string"}},
                "required": ["key"],
            },
        ),
        Tool(
            name="query_audit_log",
            description="Structured SELECT on blueprint_audit_log with filters for actor/action/subject/time range.",
            inputSchema={
                "type": "object",
                "properties": {
                    "filter_dict": {"type": "object"},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 500, "default": 50},
                },
                "required": ["filter_dict"],
            },
        ),
        Tool(
            name="get_recent_failures",
            description="List recent failure records across audit log and agent_messages. Defaults to last 7 days.",
            inputSchema={
                "type": "object",
                "properties": {"since_iso": {"type": "string"}},
            },
        ),
        Tool(
            name="score_artifact_against_rubric",
            description="Deterministic 0-100 per-dimension scoring against a named rubric JSON in BLUEPRINT_ROOT/rubrics/.",
            inputSchema={
                "type": "object",
                "properties": {
                    "artifact": {"type": "string"},
                    "rubric_id": {"type": "string"},
                },
                "required": ["artifact", "rubric_id"],
            },
        ),
        Tool(
            name="diff_two_files",
            description="Unified diff of two files (must be under BLUEPRINT_ROOT). Returns hashes and line-numbered diff.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path_a": {"type": "string"},
                    "path_b": {"type": "string"},
                },
                "required": ["path_a", "path_b"],
            },
        ),
        Tool(
            name="send_message_to_claude",
            description="Insert a bus message bound for claude_cowork. ECHO calls this for async handoffs.",
            inputSchema={
                "type": "object",
                "properties": {
                    "priority": {"type": "string", "enum": ["P0","P1","P2","P3"]},
                    "payload": {"type": "object"},
                    "subject": {"type": "string"},
                    "correlation_id": {"type": "string"},
                },
                "required": ["priority", "payload"],
            },
        ),
    ]


@server.call_tool()  # type: ignore[misc]
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    dispatch = {
        "read_blueprint_context": lambda a: tool_read_blueprint_context(a["key"]),
        "query_audit_log": lambda a: tool_query_audit_log(
            a["filter_dict"], a.get("limit", 50)),
        "get_recent_failures": lambda a: tool_get_recent_failures(a.get("since_iso")),
        "score_artifact_against_rubric": lambda a: tool_score_artifact_against_rubric(
            a["artifact"], a["rubric_id"]),
        "diff_two_files": lambda a: tool_diff_two_files(a["path_a"], a["path_b"]),
        "send_message_to_claude": lambda a: tool_send_message_to_claude(
            a["priority"], a["payload"],
            a.get("subject", "echo_to_claude"),
            a.get("correlation_id"),
        ),
    }
    handler = dispatch.get(name)
    if handler is None:
        return [TextContent(type="text", text=_error("E_NOT_FOUND", f"unknown tool: {name}"))]
    try:
        result = await handler(arguments)
        return [TextContent(type="text", text=result)]
    except Exception as e:
        return [TextContent(type="text", text=_error("E_UNKNOWN", str(e), tool=name))]


async def main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    asyncio.run(main())
