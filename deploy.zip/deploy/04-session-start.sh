#!/usr/bin/env bash
# ECHO Session Start Hook v1.0
# Effective: 2026-04-20
# Purpose: Machine-enforced session bootstrap. Replaces SOUL.md markdown reads.
# Posture: LOUD FAILURE — abort session if constitution fetch fails. No silent fallback.

set -euo pipefail

CONSTITUTION_URL="${ECHO_CONSTITUTION_URL:-https://n8n-digitalmavericks-u48043.vm.elestio.app/webhook/constitution-enforcer}"
SESSION_ID="${OPENCLAW_SESSION_ID:-$(uuidgen)}"
TIMEOUT_SECONDS=15
OUTPUT_FILE="${OPENCLAW_SESSION_BRIEFING:-/tmp/echo-session-briefing-${SESSION_ID}.json}"

echo "[echo-session-start] Session: ${SESSION_ID}"
echo "[echo-session-start] Fetching constitution + active tasks + recent failures..."

HTTP_CODE=$(curl -sS --max-time "${TIMEOUT_SECONDS}" \
  -X POST "${CONSTITUTION_URL}" \
  -H "Content-Type: application/json" \
  -d "{\"session_id\":\"${SESSION_ID}\",\"requested_at\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" \
  -o "${OUTPUT_FILE}" \
  -w "%{http_code}")

if [[ "${HTTP_CODE}" != "200" ]]; then
  echo "[echo-session-start] FATAL: constitution-enforcer returned HTTP ${HTTP_CODE}" >&2
  echo "[echo-session-start] Aborting session. No silent markdown fallback." >&2
  exit 42
fi

if ! jq -e '.constitution.credential_resolver' "${OUTPUT_FILE}" >/dev/null 2>&1; then
  echo "[echo-session-start] FATAL: briefing payload malformed (missing constitution.credential_resolver)" >&2
  exit 43
fi

echo "[echo-session-start] OK. Briefing written to ${OUTPUT_FILE}"
echo "[echo-session-start] Constitution keys: $(jq -r '.constitution | keys | join(", ")' "${OUTPUT_FILE}")"
echo "[echo-session-start] Active tasks: $(jq -r '.active_tasks | length' "${OUTPUT_FILE}")"
echo "[echo-session-start] Recent failures: $(jq -r '.recent_failures | length' "${OUTPUT_FILE}")"

exit 0
