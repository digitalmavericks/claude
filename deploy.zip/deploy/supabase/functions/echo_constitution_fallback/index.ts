// ECHO Constitution Enforcer — Supabase Edge Function fallback (v1.1)
//
// Deploy:   supabase functions deploy echo_constitution_fallback --project-ref <ref>
// Endpoint: https://<ref>.supabase.co/functions/v1/echo_constitution_fallback
// Env:      SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY (auto-injected by Supabase)
//
// Contract: response payload is schema-compatible with the n8n Constitution
// Enforcer webhook with two additions:
//   - degraded_mode: true
//   - source: "edge_function_fallback"
//
// The Task Gate MUST inspect degraded_mode on every claim call and refuse
// writes while this fallback is active. See deploy/06b-task-gate-degraded-check.sql.

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SCHEMA_VERSION = "1.0";

serve(async (req: Request) => {
  const startedAt = new Date().toISOString();

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    { auth: { persistSession: false } }
  );

  // 1. Read canonical constitution rows
  const { data, error } = await supabase
    .from("immutable_decisions")
    .select("key, value")
    .eq("locked", true);

  if (error) {
    return new Response(
      JSON.stringify({ ok: false, error: error.message, source: "edge_function_fallback" }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }

  if (!data || data.length === 0) {
    return new Response(
      JSON.stringify({ ok: false, error: "no_locked_rows", source: "edge_function_fallback" }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }

  const constitution = Object.fromEntries(data.map((r: { key: string; value: unknown }) => [r.key, r.value]));

  const sessionId = req.headers.get("x-session-id") ?? "unknown";

  // 2. Audit log — this row is ALSO the signal Task Gate reads (§3.4)
  const { error: auditError } = await supabase.from("blueprint_audit_log").insert({
    actor: "edge_function_fallback",
    action: "constitution_fetch_degraded",
    subject: sessionId,
    payload: { reason: "n8n_primary_unavailable", started_at: startedAt }
  });

  if (auditError) {
    // Degrade loud: if we can't log the fallback, Task Gate can't know to refuse writes.
    return new Response(
      JSON.stringify({ ok: false, error: `audit_log_failed: ${auditError.message}`, source: "edge_function_fallback" }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }

  return new Response(
    JSON.stringify({
      constitution,
      active_tasks: [],       // unavailable without n8n execution context
      recent_failures: [],    // unavailable without n8n execution context
      generated_at: new Date().toISOString(),
      schema_version: SCHEMA_VERSION,
      degraded_mode: true,
      source: "edge_function_fallback"
    }),
    { status: 200, headers: { "Content-Type": "application/json" } }
  );
});
