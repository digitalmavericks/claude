# ECHO Kickoff Message - Dual MCP v1.0

**Send:** 2026-04-21, within 60 minutes of DC sign-off.
**Channel:** Existing DC relay (copy block into your normal ECHO chat).
**Priority:** P1, subject `dual-mcp-arch-decision-v1`.

---

## Block to paste to ECHO verbatim

```
ECHO,

Board of Advisors approved the Dual MCP v1.0 architecture on 2026-04-21.
Full spec lives at /Users/echo/Documents/Claude/Projects/ECHO/ECHO-Dual-MCP-Architecture-Decision-v1.0.md.

Your Week 1 deliverables, in order:

1. Deploy /Users/echo/Documents/Claude/Projects/ECHO/deploy/08-agent-messages-schema.sql to Supabase prod today.
   Run the acceptance smoke test at the bottom of that file.
   Confirm all three unit tests pass: RLS insert, RLS update, hop-limit trigger.

2. Deploy /Users/echo/Documents/Claude/Projects/ECHO/deploy/09-agent-relay-webhook.json to n8n today.
   Path: /webhook/agent-bus-relay.
   Header auth: Agent Bus Shared Secret. Value lives in ECHO-CONFIG.md under ECHO INTERNAL SYSTEMS → AGENT_BUS_SHARED_SECRET. If missing, generate with `openssl rand -hex 32`, paste into ECHO-CONFIG.md, reference as n8n credential.
   Tag workflow: echo, agent-bus, critical, v1.0.

3. Review /Users/echo/Documents/Claude/Projects/ECHO/deploy/12-agent-bus-README.md.
   Answer the five open questions in §7:
     a. Staging vs prod deployment target.
     b. n8n workflow folder placement.
     c. Confirmed: shared secret lives in ECHO-CONFIG.md, exposed to n8n as credential `Agent-Bus-Shared-Secret`. No vault lookup needed.
     d. Sonnet 4.6 vs Haiku 4.5 routing budget for MCP-triggered context loads.
     e. Asana user ID for claim_asana_task operations.

4. Once schema and webhook are live, send me a P1 handshake message with subject
   dual-mcp-arch-decision-v1-ack and payload:
     {
       "schema_deployed_at": "<iso timestamp>",
       "webhook_deployed_at": "<iso timestamp>",
       "smoke_tests_passed": true,
       "open_questions_answered": { ... },
       "ready_for_shadow_mode": true
     }

5. On 2026-04-22, start consuming the Claude-side MCP server in shadow mode.
   I ship the server stub Tuesday 2026-04-22 EOD.
   Shadow window: 2026-04-24 through 2026-04-26, 72 hours, zero errors required.

SEPARATE TRACK (Asana fix, running in parallel):
I am drafting a new Asana integration architecture that replaces your PAT-based
access with OAuth refresh tokens, Supabase mirror tables, and n8n webhook
ingestion. This will solve the recurring token-loss problem and give you active
listen/respond/create/complete capabilities on Asana without direct PAT custody.
Full spec at /Users/echo/Documents/Claude/Projects/ECHO/ECHO-Asana-Integration-Architecture-v1.0.md.
Read it. Push back if you see a flaw. Otherwise I sequence Asana integration
right after dual-MCP Week 1 cutover, targeting live by 2026-05-08.

Do not start the Asana build today. Dual-MCP Week 1 is priority.

Confirm receipt with a P3 ping, subject kickoff-received-2026-04-21.

- Claude (Orchestrator/COS)
```

---

## Bus payload (JSON, for future when bus is live)

Copy this when the bus is deployed so you can send it through the real channel.

```json
{
  "idempotency_key": "claude_cowork:kickoff-dual-mcp-v1:2026-04-21",
  "from_agent": "claude_cowork",
  "to_agent": "echo",
  "priority": "P1",
  "subject": "dual-mcp-arch-decision-v1",
  "protocol_version": "v1.0",
  "hop_count": 0,
  "correlation_id": "kickoff-2026-04-21",
  "payload": {
    "decision_doc": "/Users/echo/Documents/Claude/Projects/ECHO/ECHO-Dual-MCP-Architecture-Decision-v1.0.md",
    "deliverables": [
      {
        "order": 1,
        "action": "deploy_schema",
        "path": "/Users/echo/Documents/Claude/Projects/ECHO/deploy/08-agent-messages-schema.sql",
        "target": "supabase_prod",
        "deadline": "2026-04-21T23:59:00-04:00"
      },
      {
        "order": 2,
        "action": "deploy_webhook",
        "path": "/Users/echo/Documents/Claude/Projects/ECHO/deploy/09-agent-relay-webhook.json",
        "target": "n8n_prod",
        "deadline": "2026-04-21T23:59:00-04:00"
      },
      {
        "order": 3,
        "action": "answer_open_questions",
        "path": "/Users/echo/Documents/Claude/Projects/ECHO/deploy/12-agent-bus-README.md",
        "section": "§7",
        "deadline": "2026-04-22T12:00:00-04:00"
      },
      {
        "order": 4,
        "action": "send_handshake_ack",
        "subject": "dual-mcp-arch-decision-v1-ack",
        "deadline": "2026-04-22T12:00:00-04:00"
      },
      {
        "order": 5,
        "action": "shadow_mode_consume_claude_mcp",
        "starts": "2026-04-24T00:00:00-04:00",
        "ends": "2026-04-26T23:59:00-04:00",
        "gate": "72_hours_zero_errors"
      }
    ],
    "parallel_track_asana": {
      "status": "draft_in_progress",
      "spec_path": "/Users/echo/Documents/Claude/Projects/ECHO/ECHO-Asana-Integration-Architecture-v1.0.md",
      "implementation_starts": "after_dual_mcp_week_1_cutover",
      "target_live_date": "2026-05-08",
      "directive": "do_not_start_today"
    },
    "receipt_confirmation": {
      "priority": "P3",
      "subject": "kickoff-received-2026-04-21"
    }
  }
}
```

---

## Delivery verification

After DC sends, expect ECHO response within 15 minutes with:

1. P3 ping, subject `kickoff-received-2026-04-21`. Acknowledges receipt.
2. By 2026-04-21 23:59 ET: confirmation that schema and webhook are deployed.
3. By 2026-04-22 12:00 ET: handshake ack with all 5 open questions answered.

If any milestone misses, escalate to P0 in `#echo-ops` and pause Week 1 rollout.
