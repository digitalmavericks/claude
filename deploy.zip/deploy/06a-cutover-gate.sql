-- ECHO Blueprint v1.0 — Cutover Go/No-Go gate query (PLAY 1)
--
-- Run at 2026-04-21 10:30 ET. Enforces cutover eligibility by SQL, not judgment.
-- DC ships the cutover call based on this verdict + thumbs-up at 10:45 ET.
--
-- PASS criteria (ALL required):
--   1. >= 5 distinct sessions observed during shadow window
--   2. Zero sessions with non-empty diff payload
--   3. Window duration >= 23 hours (allows 1h slack for clock skew on start)
--
-- ANY deviation → BLOCK_CUTOVER. Reconcile seed rows or markdown, reset the
-- shadow window clock, re-run. No compromise on this gate.

WITH window_stats AS (
    SELECT
        COUNT(DISTINCT subject) AS distinct_sessions,
        COUNT(*) FILTER (WHERE jsonb_array_length(payload) > 0) AS sessions_with_diffs,
        MAX(at) - MIN(at) AS window_duration,
        MIN(at) AS window_start,
        MAX(at) AS window_end
    FROM blueprint_audit_log
    WHERE actor = 'shadow_mode'
      AND at >= '2026-04-20 11:00:00-04'
)
SELECT
    CASE
        WHEN distinct_sessions >= 5
             AND sessions_with_diffs = 0
             AND window_duration >= INTERVAL '23 hours'
        THEN 'CUTOVER_ELIGIBLE'
        ELSE 'BLOCK_CUTOVER'
    END AS verdict,
    distinct_sessions,
    sessions_with_diffs,
    window_duration,
    window_start,
    window_end,
    -- Explicit failure reasons for the post in #echo-ops
    CASE
        WHEN distinct_sessions < 5 THEN
            FORMAT('Only %s distinct sessions — need >= 5', distinct_sessions)
        WHEN sessions_with_diffs > 0 THEN
            FORMAT('%s sessions logged non-empty diff payloads', sessions_with_diffs)
        WHEN window_duration < INTERVAL '23 hours' THEN
            FORMAT('Window too short: %s elapsed — need >= 23h', window_duration)
        ELSE 'All gate conditions met'
    END AS rationale
FROM window_stats;
