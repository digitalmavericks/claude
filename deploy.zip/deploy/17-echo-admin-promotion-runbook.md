# 17 — ECHO Admin Promotion Runbook

**Version:** 1.0
**Effective:** 2026-04-22
**Owner:** DC Fawcett (Chief Maverick)
**Executor:** DC (biometric-gated browser actions only — Claude cannot perform these)
**Time to complete:** ~12 minutes across three tabs

---

## 0. Why this exists

Charter v2.0 §1.2 grants ECHO Workspace Owner / Admin / Super Admin rights across Slack, Asana, and Google Workspace. Those grants are real only when the UI flags are flipped. This is the click-by-click. No narrative, no "you might want to" — exact buttons, exact order.

All three promotions target the identity `echo@digitalmavericksmedia.com`. If that account does not yet exist in a given tool, Step 0 of that section creates it.

---

## 1. Google Workspace — promote `echo@digitalmavericksmedia.com` to Super Admin

**Why first:** Google Workspace identity is the SSO spine. Slack and Asana resolve her as the same person only if Google says so.

1. Open `https://admin.google.com` in Chrome while signed in as DC (`marketing@digitalmavericksmedia.com`).
2. Left nav → **Directory** → **Users**.
3. Search for `echo@digitalmavericksmedia.com`.
   - **If not present:** click **Add new user**. First name `ECHO`, last name `Chief of Staff`, primary email `echo`, domain `@digitalmavericksmedia.com`. Set password (you will paste it into `ECHO-CONFIG.md` under `ECHO_GOOGLE_PASSWORD=` then revoke after ECHO is signed in via OAuth refresh token). Click **Add new user**.
4. Click the user row → **Admin roles and privileges** section → **Assign roles**.
5. Check **Super Admin** → **Save**.
6. Verify: row should now show "Super Admin" badge. Takes ~30 seconds to propagate.
7. Log to `ECHO-CONFIG.md`:
   ```
   ECHO_GOOGLE_EMAIL=echo@digitalmavericksmedia.com
   ECHO_GOOGLE_ROLE=super_admin
   ECHO_GOOGLE_PROMOTED_AT=2026-04-22
   ```

**Done signal:** the Admin Console left nav now shows every section (Users, Groups, Billing, Reports, Security, Domains) when logged in as `echo@`.

---

## 2. Slack — promote `echo@digitalmavericksmedia.com` to Workspace Owner

**Why second:** Slack Owner is irreversible without another Owner present. Google Workspace access must be live first so ECHO can complete SSO if required.

1. Open `https://digitalmaverickstalk.slack.com/admin` in Chrome as DC.
2. Left nav → **Members**.
3. Search `echo` or `echo@digitalmavericksmedia.com`.
   - **If not present:** click **Invite people**, enter `echo@digitalmavericksmedia.com`, role **Member** for now (we upgrade next). Send invite. Accept the invite from `echo@` inbox (Chrome MCP can do this if needed). Return to this step.
4. Click the three-dot menu on ECHO's row → **Change account type**.
5. Select **Workspace Owner** → **Save**.
6. Slack will ask for biometric/2FA reconfirm. Complete it.
7. Verify: ECHO's row badge now reads "Workspace Owner (Primary Owner: DC)".
8. While still in admin: left nav → **Settings & permissions** → **Permissions** → verify ECHO can install apps, create channels, manage workspace.
9. Log to `ECHO-CONFIG.md`:
   ```
   SLACK_WORKSPACE=digitalmaverickstalk
   SLACK_ECHO_USER_ID=<U... — copy from her profile URL>
   SLACK_ECHO_ROLE=workspace_owner
   ```

**Done signal:** ECHO can now be @mentioned with a gold shield icon, confirming Owner tier.

---

## 3. Asana — promote ECHO to Workspace Admin

**Why third:** Asana Admin has no biometric gate, but depends on the Google Workspace identity to avoid a duplicate account.

1. Open `https://app.asana.com/0/admin/members` in Chrome as DC.
2. Search `echo@digitalmavericksmedia.com`.
   - **If not present:** click **Invite Members**, paste `echo@digitalmavericksmedia.com`, role **Member**. Send invite. Accept from ECHO's inbox. Return here.
3. Click ECHO's row → right-side panel opens.
4. Under **Role**, change from **Member** to **Admin**.
5. Confirm dialog → **Make Admin**.
6. Scroll down to **Workspace access** → verify all projects and portfolios are visible.
7. Grant **Portfolio Admin** on the `Digital Mavericks Media` portfolio: open portfolio → Share → add `echo@` as **Admin**.
8. Log to `ECHO-CONFIG.md`:
   ```
   ASANA_ECHO_USER_GID=<copy from the URL when viewing her profile: asana.com/0/{GID}>
   ASANA_ECHO_ROLE=admin
   ASANA_WORKSPACE_GID=<from existing config>
   ```

**Done signal:** ECHO's avatar now shows the Admin shield on every task in every project.

---

## 4. Facebook / Meta Business Manager

**Status:** ECHO's personal FB profile already exists (DC created it). This step grants her Business Manager access.

1. Open `https://business.facebook.com/settings/people` as DC.
2. Click **Add People** → enter ECHO's FB-linked email (the one she uses for her profile, not `echo@digitalmavericksmedia.com` unless that's what DC registered).
3. Assign **Admin Access** on:
   - All owned Pages (PublishandProsper.ai, aIoperatorHQ.com, DC's personal page if business-delegated)
   - All Ad Accounts
   - Pixel access
4. Click **Invite**. ECHO accepts in her FB account.
5. Log to `ECHO-CONFIG.md`:
   ```
   FB_ECHO_BUSINESS_ACCESS=admin
   FB_ECHO_GRANTED_AT=2026-04-22
   ```

**Skip if:** DC has already done this. Verify by checking ECHO's Business Manager dashboard shows the company's Pages.

---

## 5. Bill.com debit card association

**Status:** card exists and is controlled by Bill.com with $100/mo cap and DC-held freeze.

1. Open Bill.com admin → **Spend & Expense** → **Cards**.
2. Locate ECHO's card → verify:
   - Monthly limit: $100
   - Auto-decline on breach: ON
   - Freeze control: DC's account only
3. Copy the last-4 and card nickname into `ECHO-CONFIG.md`:
   ```
   ECHO_DEBIT_LAST4=<xxxx>
   ECHO_DEBIT_NICKNAME=ECHO-OPS-100
   ECHO_DEBIT_MONTHLY_CAP=100
   ```
4. ECHO uses the card via Bill.com virtual card API, not by scraping the number. Ensure the Bill.com API key is in `ECHO-CONFIG.md` under `BILLCOM_API_KEY=`.

**Done signal:** a test $1 charge via Stripe's test mode processes, and month-to-date shows $1 consumed of $100.

---

## 6. Post-promotion verification (Claude runs this, DC watches)

After all four are complete, Claude executes the verification script which ECHO will also run on every session start:

```bash
/Users/echo/Documents/Claude/Projects/ECHO/deploy/verify-echo-identity.sh
```

That script (Claude writes next — not in this runbook) checks:
- `curl` to Slack API with ECHO's bot token → `auth.test` returns `is_owner: true`
- Asana API → `GET /users/me` returns `role: "admin"`
- Google Admin SDK → `users.get(echo@)` returns `isAdmin: true`
- Bill.com API → card status `active`, monthly cap `100`

All four green = ECHO is promoted. Any red = specific failure to fix before Charter v2 goes live.

---

## 7. Irreversibility notes

- **Slack Owner:** only another Owner can demote. DC remains Primary Owner; ECHO is secondary. If ECHO ever needs to be demoted, DC does it from the same admin page in under 30 seconds.
- **Google Super Admin:** demotion is a single checkbox in Admin Console > Users > Admin roles. No waiting period.
- **Asana Admin:** demotion is instant, no approval needed.
- **Bill.com freeze:** card stops processing in under 10 seconds when DC flips the freeze toggle. Use this as the blast-radius governor, not ECHO's judgment.

---

## 8. Sequence summary (the whole runbook on one screen)

1. **Google Admin** → Users → echo@ → Assign Super Admin. *(3 min)*
2. **Slack Admin** → Members → echo@ → Change to Workspace Owner. *(3 min)*
3. **Asana Admin** → Members → echo@ → Change to Admin + Portfolio Admin. *(2 min)*
4. **Meta Business Manager** → People → Add echo@ as Admin. *(2 min)*
5. **Bill.com** → Verify card config. *(1 min)*
6. **Log all IDs and roles** to `ECHO-CONFIG.md`. *(1 min)*
7. **Run** `verify-echo-identity.sh`. Expect all green. *(30 sec)*

Total: ~12 minutes. DC completes steps 1-5. Claude writes the loader updates and runs step 7.

---

## 9. After this runbook

Append to Charter v2 §9 first-run acknowledgment message this line:

> Admin promotions verified: Google Super Admin, Slack Workspace Owner, Asana Admin, Meta Business Admin, Bill.com card active with $100 cap. Operating under full Charter authority.

ECHO posts that to `#echo-ops` on first cutover load. DC sees it and knows the identity layer is complete.
