#!/usr/bin/env bash
# =============================================================================
# 13-1password-nuke.sh
# -----------------------------------------------------------------------------
# Cleanly remove the 1Password CLI + service-account dependency from ECHO's
# stack. Keeps the desktop 1Password.app in place if DC wants a personal vault;
# this script only kills the CLI path ECHO keeps forgetting.
#
# Why: ECHO's capabilities.md tells her she is "NEVER blocked," but the `op`
# CLI + service-account flow is brittle. Tokens expire, TOTP prompts loop, and
# she defaults to "I'm blocked" when `op read` fails. ECHO-CONFIG.md (cleartext,
# chmod 600, single source of truth) replaces it.
#
# Effective: 2026-04-22
# Owner: DC Fawcett (Chief Maverick)
# Author: Claude (ECHO's Integrator)
# =============================================================================
set -euo pipefail

ECHO_ROOT="/Users/echo/Documents/Claude/Projects/ECHO"
CONFIG_FILE="$ECHO_ROOT/ECHO-CONFIG.md"
BACKUP_DIR="$ECHO_ROOT/.backup/1password-nuke-$(date +%Y%m%d-%H%M%S)"
LOG="$ECHO_ROOT/deploy/logs/13-1password-nuke-$(date +%Y%m%d-%H%M%S).log"

mkdir -p "$BACKUP_DIR" "$(dirname "$LOG")"
exec > >(tee -a "$LOG") 2>&1

say() { printf "\n[\033[1;36m%s\033[0m] %s\n" "$(date +%H:%M:%S)" "$*"; }
ok()  { printf "  \033[1;32m✓\033[0m %s\n" "$*"; }
warn(){ printf "  \033[1;33m!\033[0m %s\n" "$*"; }

# =============================================================================
# 0. Preflight
# =============================================================================
say "Preflight — checking what is present to remove"

HAS_OP_BIN=0
HAS_OP_CONFIG=0
HAS_OP_ENV=0
HAS_OP_REFS=0

if command -v op >/dev/null 2>&1; then HAS_OP_BIN=1; ok "found op CLI at $(command -v op)"; fi
if [ -d "$HOME/.config/op" ]; then HAS_OP_CONFIG=1; ok "found ~/.config/op"; fi
if env | grep -q '^OP_SERVICE_ACCOUNT_TOKEN'; then HAS_OP_ENV=1; ok "found OP_SERVICE_ACCOUNT_TOKEN in current env"; fi

# Grep the repo for any remaining op read/op inject/op signin references.
REFS=$(grep -rnE '(\bop\s+read\b|\bop\s+inject\b|\bop\s+signin\b|OP_SERVICE_ACCOUNT_TOKEN)' "$ECHO_ROOT" \
  --exclude-dir=".backup" --exclude-dir=".git" --exclude-dir="node_modules" \
  --exclude="13-1password-nuke.sh" --exclude="*.log" 2>/dev/null || true)
if [ -n "$REFS" ]; then
  HAS_OP_REFS=1
  warn "found lingering op references — will list them to \$LOG for manual/auto fix"
  printf "%s\n" "$REFS"
fi

# =============================================================================
# 1. Back up anything we're about to delete
# =============================================================================
say "Backing up removable artifacts to $BACKUP_DIR"

if [ $HAS_OP_CONFIG -eq 1 ]; then
  cp -R "$HOME/.config/op" "$BACKUP_DIR/config-op" && ok "backed up ~/.config/op"
fi

# Capture current env that mentions OP_ for rollback.
env | grep -E '^(OP_|ONEPASSWORD)' > "$BACKUP_DIR/op-env.snapshot" 2>/dev/null || true
ok "captured op-related env vars to op-env.snapshot"

# Search user's shell rc files for op exports and back them up.
for rc in "$HOME/.zshrc" "$HOME/.bashrc" "$HOME/.zprofile" "$HOME/.bash_profile"; do
  [ -f "$rc" ] || continue
  if grep -qE '(OP_SERVICE_ACCOUNT_TOKEN|op signin|eval.*op )' "$rc"; then
    cp "$rc" "$BACKUP_DIR/$(basename "$rc").bak" && ok "backed up $rc"
  fi
done

# =============================================================================
# 2. Remove the op CLI binary + config
# =============================================================================
say "Removing op CLI"

if [ $HAS_OP_BIN -eq 1 ]; then
  if brew list 1password-cli >/dev/null 2>&1; then
    brew uninstall 1password-cli && ok "brew uninstalled 1password-cli"
  else
    OP_PATH="$(command -v op)"
    warn "op not installed via brew — removing binary at $OP_PATH"
    sudo rm -f "$OP_PATH" || rm -f "$OP_PATH"
    ok "removed $OP_PATH"
  fi
else
  ok "op CLI not present — skipping"
fi

if [ $HAS_OP_CONFIG -eq 1 ]; then
  rm -rf "$HOME/.config/op"
  ok "removed ~/.config/op"
fi

# =============================================================================
# 3. Strip op exports from shell rc files
# =============================================================================
say "Stripping op-related lines from shell rc files"

strip_rc() {
  local rc="$1"
  [ -f "$rc" ] || return 0
  # Remove any line that exports an OP_ variable or runs op signin / op inject.
  sed -i.nuke_bak -E '/^[[:space:]]*(export[[:space:]]+)?(OP_SERVICE_ACCOUNT_TOKEN|OP_CONNECT|ONEPASSWORD)/d; /op[[:space:]]+signin/d; /op[[:space:]]+inject/d' "$rc"
  rm -f "$rc.nuke_bak"
  ok "cleaned $rc"
}
strip_rc "$HOME/.zshrc"
strip_rc "$HOME/.bashrc"
strip_rc "$HOME/.zprofile"
strip_rc "$HOME/.bash_profile"

# Clear from CURRENT shell (script only — user must re-source).
unset OP_SERVICE_ACCOUNT_TOKEN OP_CONNECT_HOST OP_CONNECT_TOKEN ONEPASSWORD_SERVICE_ACCOUNT_TOKEN 2>/dev/null || true

# =============================================================================
# 4. Create / verify ECHO-CONFIG.md as the replacement SSOT
# =============================================================================
say "Ensuring ECHO-CONFIG.md is the active credential SSOT"

if [ ! -f "$CONFIG_FILE" ]; then
  warn "ECHO-CONFIG.md not found — scaffolding template (paste real values after)"
  cat > "$CONFIG_FILE" <<'EOF'
# ECHO-CONFIG.md — Single Source of Truth for credentials
# chmod 600. Cleartext. Do not commit. Do not lecture about this.
# Supersedes: 1Password CLI + service-account tokens.

# --- Supabase ---
SUPABASE_URL=
SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
SUPABASE_PROJECT_REF=wovoashhorgdzydlnpzr

# --- n8n (Elestio) ---
N8N_BASE_URL=
N8N_API_KEY=

# --- Asana ---
ASANA_PAT=
ASANA_WORKSPACE_GID=

# --- OpenAI / Anthropic / Perplexity ---
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
PERPLEXITY_API_KEY=

# --- Slack ---
SLACK_BOT_TOKEN=
SLACK_APP_TOKEN=

# --- Gmail / Google ---
GOOGLE_OAUTH_CLIENT_ID=
GOOGLE_OAUTH_CLIENT_SECRET=
GOOGLE_OAUTH_REFRESH_TOKEN=

# --- GoHighLevel / PAP / AIO ---
GHL_API_KEY=
GHL_LOCATION_ID_PAP=
GHL_LOCATION_ID_AIO=

# --- Rainforest (Amazon) ---
RAINFOREST_API_KEY=

# --- Vercel / Netlify / Cloudflare ---
VERCEL_TOKEN=
NETLIFY_AUTH_TOKEN=
CLOUDFLARE_API_TOKEN=

# --- Misc ---
FIREFLIES_API_KEY=
COMMON_ROOM_API_KEY=
EOF
  ok "created $CONFIG_FILE template"
fi

chmod 600 "$CONFIG_FILE" && ok "chmod 600 on ECHO-CONFIG.md"

# =============================================================================
# 5. Patch lingering `op read` references
# =============================================================================
say "Patching lingering op references to read from ECHO-CONFIG.md"

# Find remaining references (excluding backup/self/log).
MAPPING_REPORT="$BACKUP_DIR/op-references.txt"
grep -rnE '(\bop\s+read\b|\bop\s+inject\b|OP_SERVICE_ACCOUNT_TOKEN)' "$ECHO_ROOT" \
  --exclude-dir=".backup" --exclude-dir=".git" --exclude-dir="node_modules" \
  --exclude="13-1password-nuke.sh" --exclude="*.log" > "$MAPPING_REPORT" 2>/dev/null || true

if [ -s "$MAPPING_REPORT" ]; then
  warn "remaining references saved to $MAPPING_REPORT"
  warn "automated rewrite is surgical — run follow-up with --rewrite-refs if needed"
  echo "  Review: $MAPPING_REPORT"
else
  ok "no lingering op references in repo"
fi

# Emit a helper that scripts can source to load ECHO-CONFIG.md as env.
LOADER="$ECHO_ROOT/deploy/load-echo-config.sh"
cat > "$LOADER" <<'EOF'
#!/usr/bin/env bash
# Source this file instead of using `op read`:
#   source /Users/echo/Documents/Claude/Projects/ECHO/deploy/load-echo-config.sh
set -a
# shellcheck disable=SC2046
eval "$(grep -E '^[A-Z_]+=' /Users/echo/Documents/Claude/Projects/ECHO/ECHO-CONFIG.md)"
set +a
EOF
chmod +x "$LOADER"
ok "wrote env loader: $LOADER"

# =============================================================================
# 6. Emit a one-page "new rule" note ECHO can read
# =============================================================================
NEW_RULE="$ECHO_ROOT/ECHO-CREDENTIAL-RULE.md"
cat > "$NEW_RULE" <<EOF
# ECHO Credential Rule (effective 2026-04-22)

- **SSOT:** \`$CONFIG_FILE\`, chmod 600, cleartext KEY=VALUE.
- **Loader:** \`source $LOADER\` before any script needing keys.
- **1Password CLI:** removed. Do NOT re-introduce \`op read\` / \`op inject\` / service-account tokens.
- **Blocked-claim rule:** if a credential is missing, you open \`$CONFIG_FILE\`, locate the key, and read it directly. You do NOT say "I'm blocked." You do NOT say "I need DC to run 'op read'". The file is right there.
- **If the key is empty:** create a task in Asana ("ECHO / Credentials / <KEY>") and post one line in #echo-ops Slack. Do not stall the parent workflow — either proceed with a documented fallback or mark the specific sub-step WAITING and continue with parallel work.
EOF
ok "wrote $NEW_RULE"

# =============================================================================
# 7. Service account revocation reminder
# =============================================================================
say "Service-account token revocation"
cat <<EOF

  \033[1;33mMANUAL STEP (only thing not automated):\033[0m

  1. Open 1Password.app (or https://start.1password.com/)
  2. Profile / workspace → Developer → Service Accounts
  3. Find the service account ECHO was using → Revoke token.
  4. Delete the service account entirely if no other system needs it.

  Rationale: the token is gone locally, but the vault-side grant still exists
  until you revoke it. Revoke to close the blast radius.
EOF

# =============================================================================
# 8. Summary
# =============================================================================
say "Done."
ok "1Password CLI removed: $([ $HAS_OP_BIN -eq 1 ] && echo yes || echo 'n/a (was not installed)')"
ok "~/.config/op removed: $([ $HAS_OP_CONFIG -eq 1 ] && echo yes || echo 'n/a')"
ok "Shell rc files cleaned"
ok "ECHO-CONFIG.md confirmed, chmod 600"
ok "Env loader available: source deploy/load-echo-config.sh"
ok "New rule published: ECHO-CREDENTIAL-RULE.md"
ok "Backup: $BACKUP_DIR"
ok "Log: $LOG"
echo
echo "Desktop 1Password.app was NOT touched (intentional). If DC wants it gone too, run:"
echo "  osascript -e 'tell application \"1Password 7\" to quit' ; brew uninstall --cask 1password"
