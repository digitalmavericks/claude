#!/usr/bin/env bash
# ============================================================================
# claude-to-echo-client.sh  v1.0
# Effective: 2026-04-21
# ----------------------------------------------------------------------------
# Purpose: Send a message from claude_cowork to echo via the agent bus relay.
# Transport: HTTPS POST to n8n webhook with shared-secret header auth.
# Fallback: local WAL at deploy/logs/bus-wal.jsonl when relay unreachable.
# ============================================================================

set -euo pipefail

# ------------------------------------------------------------------------
# Config. Shared secret comes from env var AGENT_BUS_SHARED_SECRET.
# That value is mirrored in two places:
#   1. ECHO-CONFIG.md (project root) — source of truth that ECHO reads
#      every session under ECHO INTERNAL SYSTEMS → AGENT_BUS_SHARED_SECRET.
#   2. n8n credential "Agent-Bus-Shared-Secret" — used by the relay workflow.
# Export AGENT_BUS_SHARED_SECRET in your shell before invoking this script.
# ------------------------------------------------------------------------

RELAY_URL="${AGENT_BUS_RELAY_URL:-https://n8n-digitalmavericks-u48043.vm.elestio.app/webhook/agent-bus-relay}"
SHARED_SECRET="${AGENT_BUS_SHARED_SECRET:-}"
WAL_PATH="${AGENT_BUS_WAL_PATH:-/Users/echo/Documents/Claude/Projects/ECHO/deploy/logs/bus-wal.jsonl}"
FROM_AGENT="claude_cowork"
TO_AGENT="echo"
PROTOCOL_VERSION="v1.0"

MAX_RETRIES=3
RETRY_BACKOFF_BASE=2  # seconds. Attempts: 2, 4, 8.

# ------------------------------------------------------------------------
# Arg parsing.
# ------------------------------------------------------------------------

PRIORITY=""
SUBJECT=""
PAYLOAD_INLINE=""
PAYLOAD_FILE=""
CORRELATION_ID=""
HOP_COUNT=0

usage() {
    cat <<EOF
Usage: $0 --priority <P0|P1|P2|P3> --subject <subject> (--payload <json> | --payload-file <path>) [--correlation-id <id>] [--hop <n>]

Required env:
  AGENT_BUS_SHARED_SECRET   Shared secret header value.
Optional env:
  AGENT_BUS_RELAY_URL       Override relay URL (default: prod n8n).
  AGENT_BUS_WAL_PATH        Override WAL path.
EOF
    exit 1
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --priority)        PRIORITY="$2"; shift 2 ;;
        --subject)         SUBJECT="$2"; shift 2 ;;
        --payload)         PAYLOAD_INLINE="$2"; shift 2 ;;
        --payload-file)    PAYLOAD_FILE="$2"; shift 2 ;;
        --correlation-id)  CORRELATION_ID="$2"; shift 2 ;;
        --hop)             HOP_COUNT="$2"; shift 2 ;;
        -h|--help)         usage ;;
        *)                 echo "Unknown arg: $1" >&2; usage ;;
    esac
done

if [[ -z "$PRIORITY" || -z "$SUBJECT" ]]; then
    usage
fi

if [[ -z "$PAYLOAD_INLINE" && -z "$PAYLOAD_FILE" ]]; then
    echo "ERROR: Must provide --payload or --payload-file" >&2
    exit 2
fi

if [[ -z "$SHARED_SECRET" ]]; then
    echo "ERROR: AGENT_BUS_SHARED_SECRET env var not set" >&2
    exit 3
fi

case "$PRIORITY" in
    P0|P1|P2|P3) ;;
    *) echo "ERROR: priority must be P0, P1, P2, or P3" >&2; exit 4 ;;
esac

# ------------------------------------------------------------------------
# Load payload.
# ------------------------------------------------------------------------

if [[ -n "$PAYLOAD_FILE" ]]; then
    if [[ ! -r "$PAYLOAD_FILE" ]]; then
        echo "ERROR: payload file not readable: $PAYLOAD_FILE" >&2
        exit 5
    fi
    PAYLOAD="$(cat "$PAYLOAD_FILE")"
else
    PAYLOAD="$PAYLOAD_INLINE"
fi

# Validate JSON.
if ! echo "$PAYLOAD" | python3 -c "import json,sys; json.load(sys.stdin)" 2>/dev/null; then
    echo "ERROR: payload is not valid JSON" >&2
    exit 6
fi

# ------------------------------------------------------------------------
# Generate idempotency key.
# Format: {from}:{subject}:{sha256(payload)[:16]}:{iso_date}
# ------------------------------------------------------------------------

ISO_DATE="$(date -u +%Y-%m-%d)"
PAYLOAD_HASH="$(echo -n "$PAYLOAD" | shasum -a 256 | cut -c1-16)"
IDEMPOTENCY_KEY="${FROM_AGENT}:${SUBJECT}:${PAYLOAD_HASH}:${ISO_DATE}"

# ------------------------------------------------------------------------
# Build request body.
# ------------------------------------------------------------------------

REQUEST_BODY="$(python3 <<PYEOF
import json, sys
body = {
    "idempotency_key": "$IDEMPOTENCY_KEY",
    "from_agent": "$FROM_AGENT",
    "to_agent": "$TO_AGENT",
    "priority": "$PRIORITY",
    "subject": "$SUBJECT",
    "payload": json.loads('''$PAYLOAD'''),
    "protocol_version": "$PROTOCOL_VERSION",
    "hop_count": $HOP_COUNT,
    "correlation_id": "$CORRELATION_ID" or None,
}
print(json.dumps(body))
PYEOF
)"

# ------------------------------------------------------------------------
# WAL write (always, before attempting send).
# ------------------------------------------------------------------------

mkdir -p "$(dirname "$WAL_PATH")"
WAL_ENTRY="$(python3 <<PYEOF
import json, datetime
entry = {
    "t": datetime.datetime.utcnow().isoformat() + "Z",
    "op": "send",
    "idempotency_key": "$IDEMPOTENCY_KEY",
    "status": "wal_pending",
    "payload_hash": "$PAYLOAD_HASH",
    "priority": "$PRIORITY",
    "subject": "$SUBJECT"
}
print(json.dumps(entry))
PYEOF
)"
echo "$WAL_ENTRY" >> "$WAL_PATH"

# ------------------------------------------------------------------------
# Send with retry.
# ------------------------------------------------------------------------

ATTEMPT=0
SUCCESS=false
LAST_ERROR=""

while [[ $ATTEMPT -lt $MAX_RETRIES ]]; do
    ATTEMPT=$((ATTEMPT + 1))

    HTTP_CODE=$(curl -sS -o /tmp/agent-bus-response-$$.json -w "%{http_code}" \
        -X POST "$RELAY_URL" \
        -H "Content-Type: application/json" \
        -H "X-Agent-Bus-Secret: $SHARED_SECRET" \
        -H "X-Agent-From: $FROM_AGENT" \
        --max-time 10 \
        --data "$REQUEST_BODY" \
        2>/dev/null) || HTTP_CODE="000"

    if [[ "$HTTP_CODE" == "200" ]]; then
        SUCCESS=true
        break
    fi

    LAST_ERROR="http_code=$HTTP_CODE body=$(cat /tmp/agent-bus-response-$$.json 2>/dev/null | head -c 500)"

    if [[ $ATTEMPT -lt $MAX_RETRIES ]]; then
        SLEEP_FOR=$((RETRY_BACKOFF_BASE ** ATTEMPT))
        sleep $SLEEP_FOR
    fi
done

# ------------------------------------------------------------------------
# Update WAL with final status.
# ------------------------------------------------------------------------

if [[ "$SUCCESS" == true ]]; then
    RESPONSE="$(cat /tmp/agent-bus-response-$$.json)"
    FINAL_ENTRY="$(python3 <<PYEOF
import json, datetime
entry = {
    "t": datetime.datetime.utcnow().isoformat() + "Z",
    "op": "send_ack",
    "idempotency_key": "$IDEMPOTENCY_KEY",
    "status": "wal_delivered",
    "response": json.loads('''$RESPONSE''')
}
print(json.dumps(entry))
PYEOF
)"
    echo "$FINAL_ENTRY" >> "$WAL_PATH"
    echo "$RESPONSE"
    rm -f /tmp/agent-bus-response-$$.json
    exit 0
else
    FAIL_ENTRY="$(python3 <<PYEOF
import json, datetime
entry = {
    "t": datetime.datetime.utcnow().isoformat() + "Z",
    "op": "send_fail",
    "idempotency_key": "$IDEMPOTENCY_KEY",
    "status": "wal_retry_exhausted",
    "last_error": "$LAST_ERROR"
}
print(json.dumps(entry))
PYEOF
)"
    echo "$FAIL_ENTRY" >> "$WAL_PATH"
    echo "ERROR: Send failed after $MAX_RETRIES attempts. $LAST_ERROR" >&2
    echo "WAL entry recorded at $WAL_PATH. Sidecar replay will retry." >&2
    rm -f /tmp/agent-bus-response-$$.json
    exit 7
fi
