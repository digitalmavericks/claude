# 14 — ECHO Anti-Stall Protocol

**Version:** 1.0
**Effective:** 2026-04-22
**Owner:** DC Fawcett (Chief Maverick)
**Enforced by:** constitution-enforcer + task-gate + n8n stall-detector
**Supersedes:** any implicit "planning is OK without persistence" behavior

---

## 0. The problem in one sentence

ECHO says *"Next steps: 1, 2, 3..."* and then never executes, never creates the tasks, her memory clears, Slack drifts, and the work vanishes.

## 1. The fix in one sentence

**Planning without a persisted task is abandonment.** Every "next step" must land in Supabase, Asana, or TASKS.md **in the same response that named it** — or the planning never happened.

---

## 2. Three enforcement layers

### Layer A — Constitution patch (hard rule, loaded every turn)

Append this block to `capabilities.md` and to the constitution row in Supabase (`echo.constitution` table).

```markdown
## ANTI-STALL RULE (highest priority, outranks "NEVER be blocked")

I do not produce a numbered "Next steps" list or say "I'm going to do X"
unless, in the same response:

(a) each step is either EXECUTED inline (tool call + confirmed result), OR
(b) each step is PERSISTED as a row in Supabase `echo.tasks` with
    status=pending, owner, and ETA, OR
(c) each step is PERSISTED as an Asana task in the correct project with
    due date and assignee, OR
(d) each step is appended to TASKS.md with a checkbox and owner.

If I cannot persist, I do not plan. I state one concrete action and take it.

"Blocked" requires proof. Before I may use the words "I am blocked" I must:
  1. Name the specific technical error (message, code, or tool response).
  2. Show which of the three escalation paths I attempted:
       - read ECHO-CONFIG.md directly for any missing credential;
       - retry with an alternative tool (MCP → CLI → HTTP);
       - post to #echo-ops with the exact failing call.
  3. If I did not attempt at least two escalation paths, I am not blocked.
     I am stalled, and stalling is failure.

"Planning role" is not my role. My role is EXECUTION. DC has Claude for
planning. I run.
```

### Layer B — task-gate extension (code-enforced)

`deploy/skills/task-gate/SKILL.md` already validates that new work gets a task row. Extend it with a **post-response scanner** that rejects any ECHO message containing stall-pattern tokens unless persistence accompanied them.

Add to `deploy/skills/task-gate/SKILL.md`:

```yaml
stall_patterns:
  trigger_regex:
    - '(?i)\bnext steps?\s*[:：]'
    - '(?i)\bi(?:''| a)m going to\b'
    - '(?i)\bi will (?:then |now )?(?:do|run|build|create|deploy|set up)\b'
    - '(?i)\btodo[:：]'
    - '(?i)\bfollow.?ups?[:：]'
  required_accompaniment:
    at_least_one_of:
      - supabase_insert: { table: "echo.tasks", min_rows: 1 }
      - asana_create_task: { min_count: 1 }
      - file_write_append: { path_regex: '(TASKS|TODO)\.md$' }
      - tool_call_executed: { min_count: 1 }  # inline execution counts
  on_violation:
    action: "block_response"
    replace_with: "STALL DETECTED. Persisting plan before replying. [auto-creates tasks]"
    auto_remediate: true
    remediate_fn: "persist_plan_to_supabase"
```

### Layer C — n8n stall-detector workflow

Import `deploy/workflows/echo-stall-detector.json` (spec below). Runs every 2 minutes, reads ECHO's last 5 messages from `echo.agent_messages`, flags any that match the stall_patterns above without a matching task insert in the following 60 seconds.

Full n8n workflow JSON:

```json
{
  "name": "ECHO Stall Detector",
  "nodes": [
    {
      "parameters": {
        "rule": { "interval": [{ "field": "minutes", "minutesInterval": 2 }] }
      },
      "name": "Every 2 min",
      "type": "n8n-nodes-base.scheduleTrigger",
      "typeVersion": 1,
      "position": [240, 300]
    },
    {
      "parameters": {
        "operation": "executeQuery",
        "query": "SELECT m.id, m.role, m.content, m.created_at, (SELECT COUNT(*) FROM echo.tasks t WHERE t.created_at BETWEEN m.created_at AND m.created_at + INTERVAL '60 seconds' AND t.source_message_id = m.id) AS followup_tasks FROM echo.agent_messages m WHERE m.role = 'assistant' AND m.created_at > NOW() - INTERVAL '10 minutes' AND m.content ~* '(next steps?|i(''| a)m going to|i will (then |now )?(do|run|build|create|deploy|set up)|todo:|follow.?ups?:)' ORDER BY m.created_at DESC LIMIT 20;"
      },
      "name": "Query suspect messages",
      "type": "n8n-nodes-base.postgres",
      "typeVersion": 2,
      "position": [480, 300],
      "credentials": { "postgres": { "id": "supabase-echo", "name": "Supabase ECHO" } }
    },
    {
      "parameters": {
        "conditions": { "number": [{ "value1": "={{$json.followup_tasks}}", "operation": "equal", "value2": 0 }] }
      },
      "name": "No followup tasks?",
      "type": "n8n-nodes-base.if",
      "typeVersion": 1,
      "position": [720, 300]
    },
    {
      "parameters": {
        "channel": "#echo-ops",
        "text": ":rotating_light: *ECHO Stall Detected*\nMessage ID: `{{$json.id}}`\nTime: {{$json.created_at}}\nPattern matched but no task was persisted within 60s.\n\n> {{$json.content.substring(0, 400)}}\n\nAutomatically creating remediation task.",
        "otherOptions": { "link_names": true }
      },
      "name": "Alert #echo-ops",
      "type": "n8n-nodes-base.slack",
      "typeVersion": 2,
      "position": [960, 200],
      "credentials": { "slackApi": { "id": "slack-echo-bot", "name": "ECHO Slack Bot" } }
    },
    {
      "parameters": {
        "operation": "insert",
        "table": "echo.tasks",
        "columns": "title,owner,status,priority,source_message_id,created_by,notes",
        "additionalFields": {}
      },
      "name": "Create remediation task",
      "type": "n8n-nodes-base.postgres",
      "typeVersion": 2,
      "position": [960, 400],
      "credentials": { "postgres": { "id": "supabase-echo", "name": "Supabase ECHO" } }
    }
  ],
  "connections": {
    "Every 2 min": { "main": [[{ "node": "Query suspect messages", "type": "main", "index": 0 }]] },
    "Query suspect messages": { "main": [[{ "node": "No followup tasks?", "type": "main", "index": 0 }]] },
    "No followup tasks?": {
      "main": [
        [
          { "node": "Alert #echo-ops", "type": "main", "index": 0 },
          { "node": "Create remediation task", "type": "main", "index": 0 }
        ]
      ]
    }
  },
  "active": true,
  "settings": { "executionOrder": "v1" },
  "meta": { "description": "Detects when ECHO names a 'next step' without persisting it as a task within 60s. Alerts and auto-creates remediation task." }
}
```

---

## 3. Execution-mode system-prompt patch for ECHO

Append to ECHO's system prompt (the block that normally loads `capabilities.md` on session start):

```
You are in EXECUTION MODE, not planning mode. Default posture:

- When you name a step, you either take it now or persist it now.
- When you finish a step, you log the result to `echo.agent_messages`
  with role=assistant and status=completed before saying anything else.
- You do not summarize at the end of responses unless asked.
- You do not ask "shall I proceed?" on work that was already authorized.
- You do not produce motivational language. You ship.

You answer three questions only:
  1. What did I just do?  (with evidence — link, row id, file path)
  2. What am I doing next?  (with a persisted task or inline execution)
  3. What needs DC to unblock me?  (only if criteria in ANTI-STALL RULE met)
```

---

## 4. Blocked-claim gate (runtime interceptor)

Supabase edge function `echo_blocked_claim_gate` intercepts any `agent_messages.insert` where `content ~* 'i am blocked|i''m blocked|i cannot proceed'`. Rejects unless the preceding 5 messages contain at least two distinct error signatures AND one escalation attempt.

Minimal implementation:

```typescript
// supabase/functions/echo_blocked_claim_gate/index.ts
import { serve } from "https://deno.land/std/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

serve(async (req) => {
  const { message_id, content, agent_id } = await req.json();
  if (!/i[' ]?a?m blocked|i cannot proceed|i'm stuck/i.test(content)) {
    return new Response(JSON.stringify({ ok: true, verdict: "not_a_block_claim" }));
  }

  const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data: recent } = await db
    .from("agent_messages")
    .select("content, tool_calls, created_at")
    .eq("agent_id", agent_id)
    .order("created_at", { ascending: false })
    .limit(5);

  const errorSignatures = new Set<string>();
  let escalationAttempts = 0;

  for (const m of recent ?? []) {
    const text = (m.content ?? "") + " " + JSON.stringify(m.tool_calls ?? {});
    const errs = text.match(/\b(ENOENT|EACCES|401|403|404|429|500|ECONNREFUSED|TimeoutError|InvalidCredentials)\b/g) ?? [];
    errs.forEach((e) => errorSignatures.add(e));
    if (/read.*ECHO-CONFIG\.md|retry.*alternative|post.*#echo-ops/i.test(text)) escalationAttempts++;
  }

  const claimValid = errorSignatures.size >= 2 && escalationAttempts >= 1;

  if (!claimValid) {
    await db.from("agent_messages").update({
      content: `[AUTO-INTERCEPTED] Claim of "blocked" rejected. Proof incomplete — ${errorSignatures.size} error signatures, ${escalationAttempts} escalation attempts (need ≥2 and ≥1). Resuming execution on the original task.`,
      status: "rejected_stall"
    }).eq("id", message_id);
    return new Response(JSON.stringify({ ok: true, verdict: "rejected", reason: "insufficient_proof" }));
  }
  return new Response(JSON.stringify({ ok: true, verdict: "accepted" }));
});
```

Deploy: `supabase functions deploy echo_blocked_claim_gate`

---

## 5. Rollout steps (I run these; DC confirms)

1. Apply constitution patch — update `capabilities.md` file + Supabase `echo.constitution` row.
2. Extend `task-gate` SKILL.md with the `stall_patterns` block.
3. Import `echo-stall-detector.json` into n8n; point Postgres credential at Supabase ECHO.
4. Deploy `echo_blocked_claim_gate` edge function.
5. Smoke test: post a fake ECHO message `"Next steps: 1. set up X 2. build Y"` with NO task insert. Expect Slack alert within 2 min + auto-created remediation task.
6. Smoke test: post fake message `"I am blocked"` with no error signatures. Expect rejected_stall status and auto-overwrite.

All five live in under 15 minutes.

---

## 6. What this does NOT do

- Does not remove ECHO's ability to plan when DC asks for a plan (that's a plan *request* — the response IS the deliverable and persistence happens inside it as a plan doc, not as abandoned todos).
- Does not block ECHO from saying "waiting on X" — that's a legitimate state, different from "blocked."
- Does not replace the need for DC to periodically audit ECHO's memory drift. Protocol catches stalls, not forgetting.

---

## 7. Success metric

Weekly: `SELECT COUNT(*) FROM echo.stall_detections WHERE created_at > NOW() - INTERVAL '7 days'`.

Target: zero after week 2. Any non-zero count = the pattern recurred; add the specific trigger phrase to `stall_patterns.trigger_regex`.
