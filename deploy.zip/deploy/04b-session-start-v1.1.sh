#!/usr/bin/env bash
# ECHO session-start hook — v1.1 PRODUCTION variant (effective 2026-04-22 12:00 ET)
#
# Behavior:
#   1. PRIMARY: POST to n8n Constitution Enforcer (10s timeout, tightened from 15s).
#   2. FALLBACK: on any non-200 or timeout, POST to Supabase Edge Function
#      echo_constitution_fallback (returns degraded_mode: true).
#   3. If both fail → exit 42 (loud failure, no markdown fallback).
#   4. Exports ECHO_MODE=degraded when fallback fires so downstream skills know.
#
# Task Gate inspects blueprint_audit_log for recent edge_function_fallback rows
# and refuses writes with HTTP 503 while degraded_mode is active. See
# deploy/06b-task-gate-degraded-check.sql.
#
# Archive the v1.0 hook and this shadow variant for 7 days before deletion.

set -euo pipefail

CONSTITUTION_URL="${ECHO_CONSTITUTION_URL:-https://n8n-digitalmavericks-u48043.vm.elestio.app/webhook/constitution-enforcer}"
FALLBACK_URL="${ECHO_CONSTITUTION_FALLBACK_URL:-}"
SUPABASE_ANON_KEY="${SUPABASE_ANON_KEY:-}"
OUTPUT_FILE="${OPENCLAW_SESSION_BRIEFING:-/tmp/echo-briefing.json}"
SESSION_ID="${OPENCLAW_SESSION_ID:-$(uuidgen)}"

# ---------- PRIMARY: n8n webhook (10s) ----------
HTTP_CODE=$(curl -sS --max-time 10 -X POST "${CONSTITUTION_URL}" \
  -H "Content-Type: application/json" \
  -d "{\"session_id\":\"${SESSION_ID}\",\"requested_at\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" \
  -o "${OUTPUT_FILE}" -w "%{http_code}") || HTTP_CODE="000"

if [[ "${HTTP_CODE}" == "200" ]]; then
    # Schema verification
    if ! jq -e '.constitution.credential_resolver' "${OUTPUT_FILE}" >/dev/null 2>&1; then
        echo "FATAL: primary briefing missing .constitution.credential_resolver" >&2
        exit 43
    fi
    exit 0
fi

# ---------- FALLBACK: Supabase Edge Function (10s) ----------
if [[ -z "${FALLBACK_URL}" || -z "${SUPABASE_ANON_KEY}" ]]; then
    echo "FATAL: primary failed (HTTP ${HTTP_CODE}) and fallback not configured" >&2
    exit 42
fi

echo "WARNING: primary returned HTTP ${HTTP_CODE}, attempting Edge Function fallback" >&2

HTTP_CODE=$(curl -sS --max-time 10 -X POST "${FALLBACK_URL}" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${SUPABASE_ANON_KEY}" \
  -H "x-session-id: ${SESSION_ID}" \
  -d "{\"session_id\":\"${SESSION_ID}\"}" \
  -o "${OUTPUT_FILE}" -w "%{http_code}") || HTTP_CODE="000"

if [[ "${HTTP_CODE}" != "200" ]]; then
    echo "CRITICAL: both primary and fallback constitution sources unavailable" >&2
    exit 42
fi

# Verify fallback payload shape
if ! jq -e '.constitution.credential_resolver' "${OUTPUT_FILE}" >/dev/null 2>&1; then
    echo "FATAL: fallback briefing missing .constitution.credential_resolver" >&2
    exit 43
fi

# Confirm the fallback actually set degraded_mode — if not, something is impersonating it
DEGRADED=$(jq -r '.degraded_mode // false' "${OUTPUT_FILE}")
if [[ "${DEGRADED}" != "true" ]]; then
    echo "FATAL: fallback response did not set degraded_mode=true" >&2
    exit 43
fi

export ECHO_MODE=degraded
echo "WARNING: ECHO started in degraded_mode via Edge Function fallback." >&2
echo "         Task Gate will refuse external-state writes until primary recovers." >&2

exit 0
