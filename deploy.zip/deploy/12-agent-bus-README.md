# Agent Bus Protocol v1.0

**Scope:** Durable async message channel between `claude_cowork` (Claude in Cowork mode) and `echo` (ECHO on OpenClaw). Companion to the bidirectional MCP servers defined in `ECHO-Dual-MCP-Architecture-Decision-v1.0.md`.

**Rule of thumb:** bus for state, MCP for synchronous typed request/response, n8n for event fan-out.

---

## 1. When to use which channel

| Scenario | Channel |
|---|---|
| DC asks Claude "how many failures last week" and expects an answer in seconds | MCP (Claude-side: `get_recent_failures`) |
| Claude hands off a strategic artifact for ECHO to persist and act on tomorrow | Bus (P1) |
| ECHO detects an incident at 3 a.m. and needs Claude to know next morning | Bus (P0 with expires_at = next session) |
| ECHO executes an n8n workflow on Claude's request | MCP (ECHO-side: `execute_n8n_workflow`) |
| Post-incident rollup broadcast to both agents + Slack | n8n relay webhook, fan-out |
| Agent-to-agent status check (am I reachable?) | MCP `ping` + bus P3 echo |
| Corpus sync (attach JSON/SQL/markdown payload for downstream processing) | Bus (P1 or P2) |

If in doubt: bus. MCP is for things that must answer in under 3 seconds with a typed contract.

---

## 2. Message schema (v1.0)

```json
{
  "idempotency_key":   "uuid-or-sha256",
  "from_agent":        "claude_cowork | echo",
  "to_agent":          "claude_cowork | echo",
  "priority":          "P0 | P1 | P2 | P3",
  "subject":           "short-kebab-or-snake-case topic",
  "payload":           { /* any JSON */ },
  "protocol_version":  "v1.0",
  "hop_count":         0,
  "correlation_id":    "optional-thread-id"
}
```

### 2.1 Priority ladder

| Priority | Read-by SLA | Ack required | Typical use |
|---|---|---|---|
| P0 | <=5 minutes | Yes | Operational incident, security, compliance flag |
| P1 | <=1 hour | Yes | Strategic handoff, blueprint update, corpus sync |
| P2 | <=4 hours | Preferred | Routine status, non-blocking context |
| P3 | No SLA | No | Archival, log-only, decorative |

### 2.2 Idempotency key

Sender generates. Same key within 24 hours returns the existing row's `message_id` rather than inserting again. Receiver is idempotent by default because the key is unique.

Recommended format: `{from_agent}:{subject}:{sha256(canonical_payload)[:16]}:{iso_date}`.

### 2.3 Hop count

Sender sets 0 when originating. Every time a message is forwarded (agent A reads, transforms, sends onward), increment. Hard cap at 3. Above 3 the trigger rejects and logs to `blueprint_audit_log` with `actor='agent_bus_loop_guard'`.

### 2.4 Correlation id

Optional. Use to group request + response across the bus. Sender generates a uuid, all related messages carry the same value.

### 2.5 Protocol version

Locked at `v1.0` until Board reconvenes. Minor additions (new optional fields) can land as `v1.1` without breaking v1.0 consumers. Breaking changes force `v2.0` with explicit migration.

---

## 3. Send and receive

### 3.1 Send from Claude side

```bash
/Users/echo/Documents/Claude/Projects/ECHO/deploy/10-claude-to-echo-client.sh \
  --priority P1 \
  --subject "sepi_bootstrap_corpus_v1" \
  --payload-file /tmp/echo-failures-v1.json
```

Client handles: idempotency key generation, shared-secret header injection, POST to `https://n8n-digitalmavericks-u48043.vm.elestio.app/webhook/agent-bus-relay`, retry with exponential backoff (3 attempts, 2/4/8 second delays), local WAL write to `deploy/logs/bus-wal.jsonl`.

### 3.2 Send from ECHO side

Mirror client at `/echo/integrations/claude-bus/send.sh`. Same contract.

### 3.3 Read pending

```sql
SET app.agent_id = 'echo';  -- or 'claude_cowork'

SELECT id, idempotency_key, from_agent, priority, subject, payload, hop_count, created_at
FROM agent_messages
WHERE to_agent = current_setting('app.agent_id', true)
  AND status = 'pending'
ORDER BY priority DESC, created_at ASC
LIMIT 20;
```

### 3.4 Acknowledge

```sql
UPDATE agent_messages
SET status = 'ack',
    ack_at = now()
WHERE idempotency_key = $1
  AND to_agent = current_setting('app.agent_id', true);
```

---

## 4. Error taxonomy

All errors carry an `error_code` plus optional `error_detail`. Do not use `E_UNKNOWN` as a permanent catch-all. Any occurrence of `E_UNKNOWN` must be triaged and promoted to a named code within 7 days.

| Code | Meaning | Remedy |
|---|---|---|
| `E_AUTH` | Shared-secret header mismatch | Regenerate secret in ECHO-CONFIG.md, update n8n credential, retry |
| `E_SCHEMA` | Payload failed validation (missing field, wrong enum, wrong protocol) | Sender bug. Fix and resend. |
| `E_HOP_LIMIT` | hop_count >= 3 | Investigate loop. Likely A->B->A->B pattern. |
| `E_EXPIRED` | Message past expires_at before delivery | Receiver missed SLA. Review on-call. |
| `E_DOWNSTREAM` | Supabase, n8n, or Slack dependency failed | Check service status. Bus fallback: WAL replay. |
| `E_TIMEOUT` | No ack within priority SLA | Receiver unavailable. Escalate. |
| `E_RATE_LIMIT` | Caller exceeded rate budget | Back off, batch. |
| `E_UNKNOWN` | Uncategorized | TRIAGE WITHIN 7 DAYS. Promote to named code. |

---

## 5. Shared-secret handling

One shared secret between the two agents. Lives in `ECHO-CONFIG.md` under `ECHO INTERNAL SYSTEMS → AGENT_BUS_SHARED_SECRET`. Exposed to n8n as credential `Agent-Bus-Shared-Secret`. Both sides read from the same source.

If the secret ever needs to be changed:
1. Generate a new one: `openssl rand -hex 32`.
2. Paste into `ECHO-CONFIG.md`, commit.
3. Update the n8n credential with the new value.
4. Both agents pick up the new secret on next process restart.

This is internal infra. No rotation cadence, no vault API, no overlap window. If the secret leaks it's the same severity as any other internal credential: replace and move on.

---

## 6. Shadow mode

Before cutting MCP live, both agents write all bus traffic AND MCP traffic to the audit log. No actions are taken on MCP-received messages for 72 hours. Review window requirements per `ECHO-Dual-MCP-Architecture-Decision-v1.0.md` §4.4.

During shadow:
- Both MCPs respond to calls with no side effects (read-only).
- Bus continues to function as normal (this is the fallback path).
- Daily summary reported to `#echo-ops` at 09:00 ET.

---

## 7. Write-ahead log (WAL)

If Supabase is unreachable, sender writes the message to local WAL at `deploy/logs/bus-wal.jsonl` with status `wal_pending` and continues. A sidecar cron replays WAL entries every 60 seconds until successful insert. On successful insert the WAL entry is marked `wal_delivered`.

WAL format (one JSON object per line):

```json
{"t":"2026-04-21T15:23:11Z","op":"send","idempotency_key":"claude_cowork:...","status":"wal_pending","payload":{...}}
```

WAL file rotates weekly. Old files compressed to `bus-wal-YYYYMMDD.jsonl.gz`.

---

## 8. Testing

Every change to schema, webhook, or client requires:
- Schema change: run acceptance smoke test in §9 of `08-agent-messages-schema.sql`.
- Webhook change: send a P2 test message end-to-end and verify:
  - Row in `agent_messages` with correct fields.
  - No Slack alert (P2 is below fan-out threshold).
  - 200 response to sender with `expected_read_by` set correctly.
- Client change: run the client against a staging n8n relay and staging Supabase.

---

## 9. Open questions pending first ECHO handoff

Tracked as GitHub issue or Asana task when opened. Initial list:

1. Staging environment for bus testing (does ECHO have a staging Supabase, or do both agents test against prod under a reserved set of `idempotency_key` prefixes?).
2. Rate limits per priority (should P0 be exempt from rate-limit or just elevated budget?).
3. Max payload size. Recommend 64 KB hard limit, larger payloads use `payload.reference_url` to a Supabase storage object.
4. Compression. Recommend off for v1.0. Revisit at v1.1.

---

## 10. Change log

- **v1.0 (2026-04-21):** Initial protocol. Approved by Board of Advisors. Shadow-mode starts 2026-04-22.
