#!/usr/bin/env bash
# =============================================================================
# 16-slack-socketmode-to-events.sh
# -----------------------------------------------------------------------------
# Permanently fix ECHO's Slack drops by retiring Socket Mode and restoring
# Events API over Tailscale Funnel — the exact architecture that worked
# flawlessly for two weeks before someone flipped Socket Mode back on.
#
# Why Socket Mode fails:
#   - Designed for dev/internal apps behind firewalls.
#   - No redelivery on socket disconnect. Dropped frames = silent misses.
#   - Reconnect loop causes restart cascade → memory loss → key loss.
#
# Why Events API + Tailscale Funnel works:
#   - Stateless HTTPS POST from Slack → ECHO's tailnet endpoint.
#   - Slack retries 3x with exponential backoff on non-2xx.
#   - Tailscale Funnel provides public HTTPS on a private device, no port
#     forwarding, no public IP required.
#   - Zero persistent connection to drop.
#
# Effective: 2026-04-22
# Owner: DC Fawcett
# Author: Claude (ECHO's Integrator)
# =============================================================================
set -euo pipefail

ECHO_ROOT="/Users/echo/Documents/Claude/Projects/ECHO"
CONFIG_FILE="$ECHO_ROOT/ECHO-CONFIG.md"
HANDLER_DIR="$ECHO_ROOT/services/slack-handler"
LOG="$ECHO_ROOT/deploy/logs/16-slack-events-$(date +%Y%m%d-%H%M%S).log"

mkdir -p "$(dirname "$LOG")" "$HANDLER_DIR"
exec > >(tee -a "$LOG") 2>&1

say()  { printf "\n[\033[1;36m%s\033[0m] %s\n" "$(date +%H:%M:%S)" "$*"; }
ok()   { printf "  \033[1;32m✓\033[0m %s\n" "$*"; }
warn() { printf "  \033[1;33m!\033[0m %s\n" "$*"; }
die()  { printf "  \033[1;31m✗\033[0m %s\n" "$*"; exit 1; }

# Load credentials from ECHO-CONFIG.md
if [ -f "$ECHO_ROOT/deploy/load-echo-config.sh" ]; then
  # shellcheck source=/dev/null
  source "$ECHO_ROOT/deploy/load-echo-config.sh" || warn "loader exists but source failed"
fi

# =============================================================================
# 0. Preflight
# =============================================================================
say "Preflight"

command -v tailscale >/dev/null 2>&1 || die "tailscale not installed. brew install --cask tailscale first."
ok "tailscale: $(tailscale version | head -1)"

TS_STATUS="$(tailscale status --self --json 2>/dev/null || echo '{}')"
TS_NAME="$(echo "$TS_STATUS" | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d.get("Self",{}).get("DNSName","").rstrip("."))' 2>/dev/null || echo "")"
[ -n "$TS_NAME" ] || die "tailscale not logged in or no DNSName. Run: tailscale up"
ok "tailscale device: $TS_NAME"

command -v node >/dev/null 2>&1 || { brew install node@20; brew link --force --overwrite node@20; }
ok "node: $(node --version)"

# =============================================================================
# 1. Start Tailscale Funnel on port 443 → local 3333
# =============================================================================
say "Configuring Tailscale Funnel"

# Turn off any existing funnel config first
tailscale funnel --bg off 2>/dev/null || true
tailscale serve reset 2>/dev/null || true

# Route HTTPS 443 on the tailnet DNS name to local port 3333
tailscale serve --bg --https=443 --set-path=/slack/events http://localhost:3333/slack/events
tailscale funnel --bg 443 on
ok "funnel live: https://$TS_NAME/slack/events  →  localhost:3333"

# =============================================================================
# 2. Write the Slack Events API handler
# =============================================================================
say "Writing Slack Events API handler to $HANDLER_DIR"

cat > "$HANDLER_DIR/package.json" <<'EOF'
{
  "name": "echo-slack-handler",
  "version": "2.0.0",
  "description": "ECHO Slack Events API handler (Tailscale Funnel, no Socket Mode)",
  "main": "index.js",
  "type": "module",
  "scripts": { "start": "node index.js" },
  "dependencies": {
    "@slack/events-api": "^3.0.1",
    "express": "^4.19.2",
    "@supabase/supabase-js": "^2.43.0"
  }
}
EOF

cat > "$HANDLER_DIR/index.js" <<'EOF'
// ECHO Slack handler v2.0 — Events API over Tailscale Funnel
// Replaces Socket Mode. No WebSocket. No reconnect loop.
import express from 'express';
import crypto from 'crypto';
import { createClient } from '@supabase/supabase-js';

const PORT = 3333;
const SIGNING_SECRET = process.env.SLACK_SIGNING_SECRET;
const BOT_TOKEN = process.env.SLACK_BOT_TOKEN;
const SUPABASE = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

if (!SIGNING_SECRET || !BOT_TOKEN) {
  console.error('FATAL: SLACK_SIGNING_SECRET and SLACK_BOT_TOKEN required in env');
  process.exit(1);
}

const app = express();
app.use(express.json({
  verify: (req, _res, buf) => { req.rawBody = buf.toString('utf8'); }
}));

function verifySlack(req) {
  const ts = req.headers['x-slack-request-timestamp'];
  const sig = req.headers['x-slack-signature'];
  if (!ts || !sig) return false;
  if (Math.abs(Date.now()/1000 - Number(ts)) > 300) return false; // replay guard
  const base = `v0:${ts}:${req.rawBody}`;
  const mine = 'v0=' + crypto.createHmac('sha256', SIGNING_SECRET).update(base).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(mine), Buffer.from(sig));
}

app.post('/slack/events', async (req, res) => {
  // 1. URL verification handshake (one-time on app config save)
  if (req.body.type === 'url_verification') {
    return res.json({ challenge: req.body.challenge });
  }

  // 2. Signature verification
  if (!verifySlack(req)) return res.status(401).send('bad signature');

  // 3. ACK within 3s — Slack requires this
  res.status(200).send('ok');

  // 4. Log inbound to Supabase for audit + stall detection
  try {
    await SUPABASE.from('slack_inbound').insert({
      payload: req.body,
      retry_num: Number(req.headers['x-slack-retry-num'] ?? 0),
      retry_reason: req.headers['x-slack-retry-reason'] ?? null,
    });
  } catch (e) { console.error('supabase log fail:', e.message); }

  // 5. Async dispatch to ECHO (via Supabase queue or direct handler)
  const ev = req.body.event;
  if (ev?.type === 'app_mention' || ev?.type === 'message') {
    try {
      await SUPABASE.from('echo.agent_messages').insert({
        source: 'slack',
        channel_id: ev.channel,
        user_id: ev.user,
        thread_ts: ev.thread_ts ?? ev.ts,
        content: ev.text ?? '',
        role: 'user',
        status: 'pending'
      });
      // ECHO's main loop polls echo.agent_messages and responds.
    } catch (e) { console.error('dispatch fail:', e.message); }
  }
});

app.get('/health', (_req, res) => res.json({ ok: true, transport: 'events_api', ts: Date.now() }));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`ECHO Slack handler listening on :${PORT} (Events API, no Socket Mode)`);
});
EOF

ok "handler written"

# =============================================================================
# 3. Install deps + set up as launchd service (auto-restart on crash)
# =============================================================================
say "Installing handler dependencies"
(cd "$HANDLER_DIR" && npm install --silent)
ok "npm install complete"

say "Registering launchd service com.digitalmavericks.echo.slack"
PLIST="$HOME/Library/LaunchAgents/com.digitalmavericks.echo.slack.plist"
cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.digitalmavericks.echo.slack</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>-lc</string>
    <string>source $ECHO_ROOT/deploy/load-echo-config.sh &amp;&amp; cd $HANDLER_DIR &amp;&amp; /usr/local/bin/node index.js</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$ECHO_ROOT/deploy/logs/slack-handler.out</string>
  <key>StandardErrorPath</key><string>$ECHO_ROOT/deploy/logs/slack-handler.err</string>
</dict>
</plist>
EOF

launchctl unload "$PLIST" 2>/dev/null || true
launchctl load "$PLIST"
ok "launchd service loaded — will auto-restart on crash and on boot"

# =============================================================================
# 4. Slack app config instructions (DC executes in browser — biometric gate)
# =============================================================================
say "Slack app config — manual steps (biometric-gated, DC does these)"

cat <<EOF

  \033[1;33mDC, open https://api.slack.com/apps and select the ECHO app:\033[0m

  [ ] 1. "Socket Mode" (left nav) → toggle OFF.
  [ ] 2. "Event Subscriptions" (left nav) → toggle ON.
         Request URL: https://$TS_NAME/slack/events
         (Slack will verify it — the handler is already running, should pass instantly.)
  [ ] 3. Under "Subscribe to bot events" add:
         - app_mention
         - message.channels
         - message.groups
         - message.im
         - message.mpim
  [ ] 4. Save Changes.
  [ ] 5. "Install App" (left nav) → Reinstall to Workspace (accept new scopes).
  [ ] 6. Copy the new Bot User OAuth Token (xoxb-...) and paste into
         $CONFIG_FILE under SLACK_BOT_TOKEN=
         Then: launchctl kickstart -k gui/\$UID/com.digitalmavericks.echo.slack

  When complete, test by mentioning @echo in any channel. Expect <1s ack.

EOF

ok "Config instructions printed. Log: $LOG"

# =============================================================================
# 5. Health check right now
# =============================================================================
say "Local health check"
sleep 2
if curl -fsS http://localhost:3333/health | grep -q '"ok":true'; then
  ok "handler responding on localhost:3333"
else
  warn "handler not responding yet — check $ECHO_ROOT/deploy/logs/slack-handler.err"
fi

say "Public tailnet health check"
if curl -fsS "https://$TS_NAME/slack/events" -X POST -H 'Content-Type: application/json' \
     -d '{"type":"url_verification","challenge":"test123"}' 2>/dev/null | grep -q '401'; then
  ok "tailnet endpoint reachable (401 expected — missing signature)"
elif curl -fsS "https://$TS_NAME/health" 2>/dev/null | grep -q '"ok":true'; then
  ok "tailnet health endpoint live"
else
  warn "tailnet endpoint not yet responding — tailscale funnel takes ~30s to propagate"
fi

ok "Done. Events API handler running, launchd supervised, Tailscale Funnel live."
echo "Public Slack Request URL: https://$TS_NAME/slack/events"
