# iMessage Operator Health Check · Install Guide

**Built:** 2026-04-26 04:50 ET (DC pre-flight)
**Purpose:** Daily noon ET health check for `imessage-operator-3` and `imessage-operator-4` user sessions on the Mac. Alerts via Slack if missing. Does NOT auto-login (TCPA quiet-hours safety).

## Files in this folder

- `imessage-operator-healthcheck.sh` — the health-check script
- `com.digitalmavericks.imessage-operator-healthcheck.plist` — the LaunchAgent
- `INSTALL_README.md` — this file

## Install (3 commands · 30 seconds)

Open Terminal on the Mac mini. Run:

```bash
# 1. Make the script executable
chmod +x /Users/echo/Documents/Claude/Projects/ECHO/launchd/imessage-operator-healthcheck.sh

# 2. Copy the LaunchAgent into the user agents folder
cp /Users/echo/Documents/Claude/Projects/ECHO/launchd/com.digitalmavericks.imessage-operator-healthcheck.plist \
   ~/Library/LaunchAgents/

# 3. Load it into launchd
launchctl load ~/Library/LaunchAgents/com.digitalmavericks.imessage-operator-healthcheck.plist
```

Verify it's loaded:

```bash
launchctl list | grep digitalmavericks
```

You should see `com.digitalmavericks.imessage-operator-healthcheck` in the output.

## Test it manually (does NOT fire any iMessages)

Run the script directly:

```bash
/Users/echo/Documents/Claude/Projects/ECHO/launchd/imessage-operator-healthcheck.sh
```

Check the log:

```bash
tail -50 ~/Library/Logs/digitalmavericks/imessage-operator-healthcheck.log
```

If it's currently outside the noon-9pm ET window, the script aborts cleanly with "OUTSIDE QUIET-HOURS WINDOW" and does nothing. Safe to run anytime.

## Configure Slack alerts (optional but recommended)

Add to `/Users/echo/Documents/Claude/Projects/ECHO/ECHO-CONFIG.md`:

```
SLACK_OPS_WEBHOOK=https://hooks.slack.com/services/T.../B.../...
```

Without this, the script falls back to a macOS native notification on the Mac itself (which DC won't see while traveling). Slack webhook is the production path.

## What this does at noon ET each day

1. Check Mac timezone is in the noon-9pm ET window (TCPA safety guard — aborts otherwise)
2. For each of `imessage-operator-3` and `imessage-operator-4`:
   - Verify the user account exists
   - Get the user's UID
   - Check if their iMessage processes (`imagent` or `Messages`) are running
3. If any operator is missing → POST to Slack ops webhook + macOS notification
4. If all healthy → exit silently

## What this does NOT do

- Does NOT auto-login operator users (would risk firing queued iMessages mid-quiet-hours)
- Does NOT enter passwords, modify accounts, or change Mac state
- Does NOT run outside the noon-9pm ET window even if triggered manually

## DC's manual action when alerted

If the Slack alert fires:
1. Mac → menu bar → username → switch to operator account
2. Enter the operator's password
3. Wait for iMessage app to sync queued messages from iCloud
4. Switch back to your DC user (operator stays logged in via Fast User Switching)
5. Health check on next noon-ET run will confirm green

## Uninstall (if needed)

```bash
launchctl unload ~/Library/LaunchAgents/com.digitalmavericks.imessage-operator-healthcheck.plist
rm ~/Library/LaunchAgents/com.digitalmavericks.imessage-operator-healthcheck.plist
```

## Future upgrade path (when you're not packing)

The current version is conservative — alerts only. A future v2 could:
- Auto-login operators using stored keychain credentials (requires `security` CLI access to operator passwords stored in DC's keychain)
- Run a startup-time scheduler that defers operator login until next noon-ET window after a Mac reboot
- Auto-recover by switching to operator user via `CGSession -switchToUserID <UID>`

For now: alert-only is the right call.
