#!/bin/bash
# ════════════════════════════════════════════════════════════════════════════
# iMessage Operator Health Check — Noon ET Daily
# ════════════════════════════════════════════════════════════════════════════
# Purpose: Verify imessage-operator-3 and imessage-operator-4 user sessions
# are active on the Mac so WhatSnap.ai P2P messagesync can fire iMessages.
# This script is CONSERVATIVE: it ONLY emits a Slack alert if operators are
# missing. It does NOT auto-login them (would risk firing queued iMessages
# mid-quiet-hours).
# ════════════════════════════════════════════════════════════════════════════
# TCPA QUIET HOURS: 9:00 PM - Noon ET. Do NOT trigger any operator login
# action outside the noon-9pm ET window.
# ════════════════════════════════════════════════════════════════════════════

set -e

# Logging
LOG_DIR="$HOME/Library/Logs/digitalmavericks"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/imessage-operator-healthcheck.log"
exec >> "$LOG_FILE" 2>&1
echo ""
echo "════════════════════════════════════════════════════════════════════════"
echo "[$(date)] iMessage Operator Health Check START"

# Operators to check
OPERATORS=("imessage-operator-3" "imessage-operator-4")

# Check current ET hour to confirm we're inside the safe window (noon-9pm ET)
CURRENT_HOUR_ET=$(TZ="America/New_York" date +%H)
if [ "$CURRENT_HOUR_ET" -lt 12 ] || [ "$CURRENT_HOUR_ET" -ge 21 ]; then
  echo "[$(date)] OUTSIDE QUIET-HOURS WINDOW (current ET hour: $CURRENT_HOUR_ET). Aborting any operator action."
  echo "[$(date)] Health check ABORTED — TCPA safety guard."
  exit 0
fi

# Check each operator's session
MISSING=()
for op in "${OPERATORS[@]}"; do
  # Test 1: Does the user account exist?
  if ! id "$op" >/dev/null 2>&1; then
    echo "[$(date)] ERROR: User account '$op' does not exist on this Mac."
    MISSING+=("$op (account missing)")
    continue
  fi

  # Test 2: Get the user's UID
  OP_UID=$(id -u "$op" 2>/dev/null)

  # Test 3: Is the user session active? Check for their iMessage processes.
  if pgrep -u "$OP_UID" -x "imagent" >/dev/null 2>&1 || \
     pgrep -u "$OP_UID" -x "Messages" >/dev/null 2>&1; then
    echo "[$(date)] OK: $op (UID $OP_UID) has active iMessage session."
  else
    echo "[$(date)] MISSING: $op (UID $OP_UID) has NO active iMessage process."
    MISSING+=("$op")
  fi
done

# If any operators are missing, emit Slack alert
if [ ${#MISSING[@]} -eq 0 ]; then
  echo "[$(date)] ALL OPERATORS HEALTHY. No alert needed."
  exit 0
fi

# Slack alert
SLACK_WEBHOOK="${SLACK_OPS_WEBHOOK:-}"  # Set via env or in ECHO-CONFIG.md
if [ -z "$SLACK_WEBHOOK" ]; then
  # Try to load from ECHO-CONFIG.md
  CONFIG_FILE="$HOME/Documents/Claude/Projects/ECHO/ECHO-CONFIG.md"
  if [ -f "$CONFIG_FILE" ]; then
    SLACK_WEBHOOK=$(grep -E "^SLACK_OPS_WEBHOOK\s*=" "$CONFIG_FILE" | head -1 | cut -d= -f2- | tr -d ' \t"')
  fi
fi

MISSING_LIST=$(printf "• %s\n" "${MISSING[@]}")
PAYLOAD=$(cat <<EOF
{
  "text": "🚨 iMessage Operator Health Check FAILED at noon ET",
  "blocks": [
    {
      "type": "header",
      "text": { "type": "plain_text", "text": "🚨 iMessage Operators Missing" }
    },
    {
      "type": "section",
      "text": {
        "type": "mrkdwn",
        "text": "*Date:* $(TZ='America/New_York' date '+%Y-%m-%d %H:%M ET')\n*Status:* The following iMessage operator user sessions are NOT active on the Mac:\n\n$MISSING_LIST\n\n*Action required:* DC manually logs in each missing operator via Fast User Switching. Mac → menu bar → username → switch to operator account → enter password → leave logged in.\n\n*Why this matters:* WhatSnap.ai P2P messagesync needs each operator's iMessage app running to fire queued GHL messages. Missing operators = silent message backlog."
      }
    },
    {
      "type": "context",
      "elements": [
        { "type": "mrkdwn", "text": "Source: \`$0\` · Mac: $(hostname)" }
      ]
    }
  ]
}
EOF
)

if [ -n "$SLACK_WEBHOOK" ]; then
  echo "[$(date)] Sending Slack alert..."
  curl -s -X POST -H "Content-Type: application/json" -d "$PAYLOAD" "$SLACK_WEBHOOK" || echo "[$(date)] WARN: Slack webhook POST failed."
else
  echo "[$(date)] WARN: No SLACK_OPS_WEBHOOK configured. Alert NOT sent."
  echo "[$(date)] To configure: add SLACK_OPS_WEBHOOK=https://hooks.slack.com/... to ECHO-CONFIG.md"
fi

# macOS native notification as backup
osascript -e "display notification \"Operators missing: ${MISSING[*]}\" with title \"iMessage Health Check FAILED\" sound name \"Sosumi\"" 2>/dev/null || true

echo "[$(date)] Health check COMPLETE — alert dispatched."
