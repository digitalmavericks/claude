# Shared Operational State
**Last updated:** 2026-04-24 by Cowork

## ECHO Configuration
- **Default model:** openai-codex/gpt-5.5-pro (changed 2026-04-24, was gpt-5.4)
- **Gateway:** OpenClaw v2026.4.15, Socket Mode
- **System prompt:** Charter v4.0 deployed to ~/.openclaw/workspace/CLAUDE.md
- **n8n API key:** Persistent public-api JWT installed 2026-04-24 (replaces expired mcp-server-api JWT)
- **n8n real URL:** https://n8n-digitalmavericks-u48043.vm.elestio.app (NOT n8n.digitalmavericksmedia.com — DNS dead)
- **Heartbeat:** openrouter/openai/gpt-5-nano, every 5m, target C0APRH5BLDS
- **Tailscale Funnel:** Active at OS level (echos-mac-mini-1.tail074467.ts.net → 127.0.0.1:18789). OpenClaw tailscale.mode = "off" (managed externally)
- **Slack transport:** Socket Mode (webhook mode not supported on v2026.4.15)
- **Publishing stack:** Zernio only, executed via structured and optimized n8n flows. Blotato and Postiz are retired and no longer valid publishing paths or fallbacks.

## Infrastructure
- **Primary Mac:** Mac mini M4 24GB / 251GB SSD — ECHO-only brain (OpenClaw, n8n, automation, AI ops)
- **iMessage Mac:** PENDING PURCHASE — M1 Mac mini 16GB ($300-400 Swappa) OR Mac Studio M4 Max ($4K if AMM deal closes first)
- **iMessage operators:** 3 active lines (3 Apple IDs, 3 iPhones + 1 spare), currently still on M4 — migration pending new Mac arrival
- **WhatSnap status:** NOT locked in. SDK coming. BlueBubbles and custom scripts are alternatives.

## Known Issues
- Supabase DNS: NXDOMAIN — need project ref for direct URL (Supabase dashboard: https://supabase.com/dashboard/project/wovoashhorgdzydlnpzr)
- Mission Control Beta URL: https://mission-control-beta-vert-26.vercel.app
- n8n.digitalmavericksmedia.com DNS: Dead custom domain
- Events API migration: Blocked until OpenClaw supports webhook mode (v2026.4.22+)
- M4 SSD: was 92% full, now ~85% — recovered ~15 GB by retiring Google Drive Mirror mode (2026-04-24)
- GPT-5.5 Pro default-selection persistence: broken on gateway restart — manual re-select required, configuration bug
- Legacy credential refs: `config/mcporter.json` and `_core/startup-credentials.md` still point at old auth patterns — tech debt cleanup pending

## Skill Stack State (2026-04-24 — Phase 0 Complete)
- **Phase 0 vNext SKILL files:** `/Users/echo/Documents/Claude/Projects/ECHO/skill-upgrade-phase0-vnext/` — Board v3.0, Maverick v3.0, Webinar Intelligence v4.0 (renamed from webinar-conversion-forensics)
- **Red-team report:** same folder, 13 blocking patches applied inline
- **Live plugin-installed skills:** still v2.1 / v2 / v3.0 respectively — NOT YET HOT-SWAPPED
- **Migration Checklist §M.1 (backup + hot-swap):** PENDING DC greenlight
- **Migration Checklist §M.2 (reference-file quarantine sweep):** PENDING — ship blocker before Phase 1 produces AIO public-facing copy
- **10-test smoke suite:** not yet executed on patched vNext files

## Google Drive State (2026-04-24 — Fresh Install)
- **Mode:** Stream-only (Mirror retired — was causing SSD exhaustion)
- **Bandwidth throttle:** Removed (unlimited — pipe is 898 Mbps / 816 Mbps)
- **Local sync folders:** None (Desktop/Documents/Downloads NOT synced to Drive — declined at setup)
- **Virtual drive path:** `/Users/echo/Library/CloudStorage/GoogleDrive-echo@digitalmavericksmedia.com/Shared drives/ECHO/`
- **Cowork mount:** PENDING — DC must add Shared Drive to Cowork session after fetch completes

## Model Availability
- openai-codex/gpt-5.5-pro: LIVE (confirmed 2026-04-24)
- openai-codex/gpt-5.4: Available as fallback
- openrouter models: Full list in openclaw.json
