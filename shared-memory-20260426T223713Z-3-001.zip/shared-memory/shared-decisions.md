# Shared Decision Log
**Last updated:** 2026-04-24 by Cowork

## 2026-04-24

### DECIDED: iMessage hardware separation
- **Decision:** Buy a dedicated Mac for iMessage. M4 becomes ECHO-only brain.
- **Hardware:** M1 Mac mini 16GB ($300-400) as baseline. If an AMM/AIO deal closes first, upgrade to Mac Studio M4 Max ($4K).
- **Rationale:** 5 concurrent macOS users crashed the M4. 251GB SSD at 92% full partly from iMessage caches. Clean separation = zero resource contention.
- **Owner:** DC
- **ETA:** This week (M1 path) or within 30 days (Mac Studio path)

### DECIDED: WhatSnap is not required
- **Decision:** WhatSnap is one option among several. SDK coming. BlueBubbles (free, open source) and custom iMessage bridge scripts are viable alternatives.
- **Rationale:** Reduces per-line cost, removes vendor lock-in, enables deeper GHL integration.
- **Constraint:** iPhones are still required for SMS/MMS forwarding regardless of gateway software. Android phones cannot substitute.

### DECIDED: GPT-5.5 Pro as default model
- **Decision:** ECHO's default model upgraded from gpt-5.4 to gpt-5.5-pro via Codex OAuth.
- **Date:** 2026-04-24, confirmed working same day.

### DECIDED: n8n persistent API key
- **Decision:** Replaced session JWT (aud: mcp-server-api) with persistent public API key (aud: public-api). Kills the "groundhog day" problem of expired keys every session.
- **Date:** 2026-04-24

### DECIDED: Charter v4 deployed
- **Decision:** ECHO Autonomy Charter v4.0 installed as CLAUDE.md system prompt.
- **Modification:** §10 adapted to authorize Socket Mode (only transport OpenClaw v2026.4.15 supports). §22 First-Run Acknowledgment updated accordingly.
- **Date:** 2026-04-24

### DECIDED: Publishing path is Zernio only
- **Decision:** Blotato and Postiz are retired. Billing is cancelled. The only valid publishing path is Zernio through structured and optimized n8n workflows.
- **Rationale:** DC explicitly removed both old publishing tools from the stack and confirmed Zernio+n8n as the sole path.
- **Date:** 2026-04-24

### TABLED: AIO Infrastructure Decision Matrix
- **Status:** DC is building this himself across 7 AI platforms (Claude Opus 4.7, GPT 5.4/5.5 Pro, Perplexity, Grok 4.3, Gemini 3.1 Pro, Manus.im). ~70,000+ words generated across all platforms. Will bring final synthesis to Cowork/ECHO when ready.

### TABLED: Board of Advisors on productization
- **Status:** Sequenced AFTER the skill audit + enhancement sprint and AIO asset synthesis. DC is running a multi-model synthesis workflow first.

## 2026-04-22 (from prior sessions)

### DECIDED: 2010 Intel MacBooks are dead for iMessage
- **Rationale:** High Sierra max. WhatSnap needs Monterey (Late 2014+). Even without WhatSnap, High Sierra iMessage support is increasingly fragile.

### DECIDED: openclaw doctor --fix is BANNED
- **Rationale:** It renamed gpt-5.4 to gpt-5.4-pro, killed heartbeat block, stripped imageGenerationModel, flattened model object, removed agents, gutted Slack config. Required full backup restoration.
