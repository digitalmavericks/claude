# ECHO <-> Cowork Shared Memory

This directory is the bidirectional memory bridge between:
- **ECHO** (OpenClaw agent, runs via `~/.openclaw/workspace/CLAUDE.md`)
- **Cowork** (Claude Desktop Cowork sessions with DC)

## How it works

Both agents READ from and WRITE to this directory.

### File naming convention
- `cowork-to-echo-*.md` — Written by Cowork for ECHO to read
- `echo-to-cowork-*.md` — Written by ECHO for Cowork to read
- `shared-*.md` — Either agent can write/update

### Rules
1. Never delete another agent's files. Update or append only.
2. Include a `last-updated` timestamp in every file.
3. If you disagree with a memory, add a `## Dispute` section rather than overwriting.
4. Stale memories (>14 days without update) should be flagged, not deleted.
5. This is NOT for ephemeral task state. Only persist insights, decisions, and context that survive across sessions.

## Directory
- `shared-state.md` — Current operational state (models, services, infrastructure)
- `shared-decisions.md` — Decisions made with rationale and date
- `cowork-to-echo-briefing.md` — Latest context from Cowork sessions ECHO should know
- `echo-to-cowork-briefing.md` — (ECHO writes this) Latest context from Slack/ops Cowork should know
